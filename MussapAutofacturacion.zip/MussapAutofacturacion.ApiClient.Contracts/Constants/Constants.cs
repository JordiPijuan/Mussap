﻿using MussapAutofacturacion.Common.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.Constants
{
    public class Constants
    {
        public class Headers
        {
            public const string ContentType = "Content-Type";
            public const string Authorization = "authorization";
            public const string XIbmClientId = "x-ibm-client-id";
            public const string CacheControl = "Cache-Control";

            public class Values
            {
                public const string ApplicationJson = "application/json";
                public const string ApplicationUrlEncoded = "application/x-www-form-urlencoded";
                public const string MultiPartFormData = "multipart/form-data; boundary=1234567";
                public const string NoCache = "no-cache";
                public static string BearerToken(string token) => $"Bearer {token}";
                public static string BasicToken(string token) => $"Basic {token}";
            }
        }

        public class Parameters
        {
            public const string Undefined = "undefined";
            public const string DocumentJson = "entradaV1";
            public const string File = "file";
            public class Keys
            {
                public const string GrantType = "grant_type";
                //public const string Username = "username";
                //public const string Password = "password";
                public const string Scope = "scope";
                public const string ClientId = "client_id";
                public const string ClientSecret = "client_secret";
            }
       
        }

        public class Endpoints
        {
            public const string Services = "/servicios";
      
        }

     



        public class LogMessages
        {
            /// <summary>
            /// "The request with CaseId: '{0}' and SummaryNu: '{1}' has already been sended today."
            /// </summary>
            /// <param name="caseId">Case id</param>
            /// <param name="summaryNu">SummaryNu</param>
            /// <returns></returns>
            public static string RequestWasSendedToday(long caseId, int summaryNu)
                => string.Format(_requestWasSendedToday, caseId, summaryNu);
            private const string _requestWasSendedToday = "The request with CaseId: '{0}' and SummaryNu: '{1}' has already been sended today.";

            /// <summary>
            /// "Error processing Sinister with caseId: {0}. Post Failed with response: {1}. For request: {2}."
            /// </summary>
            /// <param name="caseId"></param>
            /// <param name="restResponseDtoJson"></param>
            /// <param name="requestJson"></param>
            /// <returns></returns>
            public static string LogRestResponse(long caseId, int summaryNu)
                => string.Format(_logRestResponse, caseId, summaryNu);
            private const string _logRestResponse = "Error processing Sinister with caseId: '{0}' and summaryNu: '{1}'.";

            /// <summary>
            /// "Error post processing Sinister with caseId: {0}. Message: {1}."
            /// </summary>
            /// <param name="caseId"></param>
            /// <param name="exceptionMessage"></param>
            /// <returns></returns>
            public static string ErrorPostProcessingSinister(long caseId, string exceptionMessage)
                => string.Format(_errorPostProcessingSinister, caseId, exceptionMessage);
            private const string _errorPostProcessingSinister = "Error post processing Sinister with caseId: {0}. Message: {1}.";

            /// <summary>
            /// "Cancelled sending of caseId: '{0}' and summaryNu: '{1}' because it had been cancelled on preprocessing."
            /// </summary>
            /// <param name="caseId"></param>
            /// <returns></returns>
            public static string CancelledSendingOnPreProcessing(long caseId, int summaryNu)
                => string.Format(_cancelledSendingOnPreProcessing, caseId, summaryNu);
            private const string _cancelledSendingOnPreProcessing = "Cancelled sending of caseId: '{0}' and summaryNu: '{1}' because it had been cancelled on preprocessing.";

            /// <summary>
            /// "Cancelled sending of caseId: '{0}' because something failed."
            /// </summary>
            /// <param name="caseId"></param>
            /// <returns></returns>
            public static string CancelledSendingByFailed(long caseId, int summaryNu)
                => string.Format(_cancelledSendingByFailed, caseId, summaryNu);
            private const string _cancelledSendingByFailed = "Cancelled sending of caseId: '{0}' and summaryNu: '{1}' because something failed.";

            /// <summary>
            /// "Error processing Sinister with caseId: {0}."
            /// </summary>
            /// <param name="caseId"></param>
            /// <returns></returns>
            public static string ErrorProcessingSinister(long caseId)
                => string.Format(_errorProcessingSinister, caseId);
            private const string _errorProcessingSinister = "Error processing Sinister with caseId: {0}.";

            /// <summary>
            /// "Error pre processing 'contado cierre siniestro' with caseId: {0}."
            /// </summary>
            /// <param name="caseId"></param>
            /// <returns></returns>
            public static string ErrorPreProcessingContadoCierreSinister(long caseId)
                => string.Format(_errorPreProcessingContadoCierreSinister, caseId);
            private const string _errorPreProcessingContadoCierreSinister = "Error pre processing 'contado cierre siniestro' with caseId: {0}.";

            /// <summary>
            /// "Error post processing 'contado cierre siniestro' with caseId: {0}."
            /// </summary>
            /// <param name="caseId"></param>
            /// <returns></returns>
            public static string ErrorPostProcessingContadoCierreSinister(long caseId)
                => string.Format(_errorPostProcessingContadoCierreSinister, caseId);
            private const string _errorPostProcessingContadoCierreSinister = "Error post processing 'contado cierre siniestro' with caseId: {0}.";

            /// <summary>
            /// "SummaryType: '{(int)summaryType}-{summaryType.ToString()}' not included in {summaryTypeHelperType.Name}."
            /// </summary>
            /// <param name="summaryType"></param>
            /// <returns></returns>
            public static string SummaryTypeNotIncludedInSummaryTypeHelper(SummaryTypes summaryType, Type summaryTypeHelperType)
                => string.Format(_summaryTypeNotIncludedInSummaryTypeHelper, (int)summaryType, summaryType.ToString(), summaryTypeHelperType.Name);
            private const string _summaryTypeNotIncludedInSummaryTypeHelper = "SummaryType: '{0}-{1}' not included in {2}.";

            /// <summary>
            /// "Failed calling de SP to send email '{0}' with parameters: '{1}' and mail data: '{2}'."
            /// </summary>
            /// <param name="spName">Stored procedure name</param>
            /// <param name="spParametersJson">Stored procedure parameters JSON</param>
            /// <param name="mailDataJson">Mail data JSON</param>
            /// <returns></returns>
            public static string FailedCallingSpSendEmail(string spName, string spParametersJson, string mailDataJson)
                => string.Format(_failedCallingSpSendEmail, spName, spParametersJson, mailDataJson);
            private const string _failedCallingSpSendEmail = "Failed calling de SP to send email '{0}' with parameters: '{1}' and mail data: '{2}'.";

            /// <summary>
            /// "Failed checking if shipment has been created on MM. CaseId: {0}."
            /// </summary>
            /// <param name="caseId">Case Id</param>
            /// <returns></returns>
            public static string FailedCheckingShipmentCreated(long caseId)
                => string.Format(_failedCheckingShipmentCreated, caseId);
            private const string _failedCheckingShipmentCreated = "Failed checking if shipment has been created on MM. CaseId: {0}.";

            /// <summary>
            /// "Error with the stored procedure: '{0}. Error code: '{1}'. Parameters: '{2}'."
            /// </summary>
            /// <param name="spName"></param>
            /// <param name="errorCode"></param>
            /// <param name="parametersJson"></param>
            /// <returns></returns>
            public static string ErrorWithStoredProcedure(string spName, int errorCode, string parametersJson)
                => string.Format(_errorWithStoredProcedure, spName, errorCode, parametersJson);
            private const string _errorWithStoredProcedure = "Error with the stored procedure: '{0}. Error code: '{1}'. Parameters: '{2}'.";

            /// <summary>
            /// "Response.State is: '{0}'."
            /// </summary>
            /// <param name="responseState">Response State string</param>
            /// <returns></returns>
            public static string ResponseStateIs(string responseState)
                => string.Format(_responseState, responseState);
            private const string _responseState = "Response.State is: '{0}'.";

            /// <summary>
            /// "Response is null for the request: {0}."
            /// </summary>
            /// <param name="requestJson"></param>
            /// <returns></returns>
            public static string ResponseIsNull(string requestJson)
                => string.Format(_nullResponse, requestJson);
            private const string _nullResponse = "Response is null for the request: {0}.";

            /// <summary>
            /// "Error sending to MM API the {0}. Trying to update movement type to '{1}'. Response: {2}."
            /// </summary>
            /// <param name="apiRequestType">Api Request Type</param>
            /// <param name="movementType">MovementType</param>
            /// <param name="responseJson">ResponseJson</param>
            /// <returns></returns>
            public static string ErrorSendingMmApiTryingUpdateMovementType(Type apiRequestType, MovementTypes movementType, string responseJson)
                => string.Format(_errorSendingMmApiTryingUpdateMovementType, apiRequestType.Name, movementType.ToString(), responseJson);
            private const string _errorSendingMmApiTryingUpdateMovementType = "Error sending to MM API the {0}. Trying to update movement type to '{1}'. Response: {2}.";

            /// <summary>
            /// "The ShipmentPending doesn't have value for {0}. ShipmentPending: '{1}'."
            /// </summary>
            /// <param name="nullPropertyName">NullPropertyName</param>
            /// <param name="shipmentPendingJson">ShipmentPendingJson</param>
            /// <returns></returns>
            public static string ShipmentPendingDoesntHaveValueFor(string nullPropertyName, string shipmentPendingJson)
                => string.Format(_shipmentPendingWithoutValueFor, nullPropertyName, shipmentPendingJson);
            private const string _shipmentPendingWithoutValueFor = "The ShipmentPending doesn't have value for {0}. ShipmentPending: '{1}'.";

            /// <summary>
            /// "Stored procedure error with CaseId: '{0}' and summaryNu: '{1}'."
            /// </summary>
            /// <param name="caseId">Case id</param>
            /// <param name="summaryNu">SummaryNu</param>
            /// <returns></returns>
            public static string SpError(long caseId, int summaryNu)
                => string.Format(_spError, caseId, summaryNu);
            private const string _spError = "Stored procedure error with CaseId: '{0}' and summaryNu: '{1}'.";

            /// <summary>
            /// "Failed fetching data from SP: {0}-{1}. With {2}: {3}."
            /// </summary>
            /// <param name="spEnum">SpEnum number</param>
            /// <param name="spEnumString">SpEnum string</param>
            /// <param name="nameOfSoredProcedureContext">Name of strored procedure context</param>
            /// <param name="spContexJson">SpContext json object</param>
            /// <returns></returns>
            public static string SpFetchDataError(int spEnum, string spEnumString, string nameOfSoredProcedureContext, string spContexJson)
                => string.Format(_spFetchDataError, spEnum, spEnumString, nameOfSoredProcedureContext, spContexJson);
            private const string _spFetchDataError = "Failed fetching data from SP: {0}-{1}. With {2}: {3}.";

            /// <summary>
            /// "Manipulated ShipmentPending with CaseId: {0} and SummaryNu: {1}."
            /// </summary>
            /// <param name="caseId">Case id</param>
            /// <param name="summaryNu">SummaryNu</param>
            /// <returns></returns>
            public static string RaiderManipulatedShipmentPending(long caseId, int summaryNu)
                => string.Format(_raiderManipulatedShipmentPending, caseId, summaryNu);
            private const string _raiderManipulatedShipmentPending = "Manipulated ShipmentPending with CaseId: {0} and SummaryNu: {1}.";

            /// <summary>
            /// "Error manipulating shipment pending with CaseId: '{0}' and SummaryNu: '{1}'. ShipmentPending Json: '{2}'."
            /// </summary>
            /// <param name="caseId">Case id</param>
            /// <param name="summaryNu">SummaryNu</param>
            /// <param name="shipmentPendingJson">Shipment pending json object</param>
            /// <returns></returns>
            public static string RaiderManipulatingError(long caseId, int summaryNu, string shipmentPendingJson)
                => string.Format(_raiderManipulatingError, caseId, summaryNu);
            private const string _raiderManipulatingError = "Error manipulating shipment pending with CaseId: '{0}' and SummaryNu: '{1}'. ShipmentPending Json: '{2}'.";
        }
    }
    }
