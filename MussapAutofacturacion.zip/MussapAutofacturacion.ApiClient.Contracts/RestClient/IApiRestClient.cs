﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.RestClient
{
    public interface IApiRestClient
    {
        //IApiResponse Post<TResponse>(IApiRequest request)
        //   where TResponse : IApiResponse;
    }
}
