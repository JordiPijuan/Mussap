﻿using MussapAutofacturacion.ApiClient.Contracts.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.RestClient.Abstract
{
    public abstract class RequestApiBase : ApiBase, IApiRequest
    {
        [JsonIgnore]
        public string Endpoint { get => ApiPahtResourcesHelper.GetResourcePath(this); }

        [JsonIgnore]
        public long CaseId { get; set; }

        [JsonIgnore]
        public int SummaryNu { get; set; }

        [JsonIgnore]
        public long ShipmentId { get; set; }

        [JsonIgnore]
        public int SummaryTypeId { get; set; }

        [JsonIgnore]
        public int? CaseTypeId { get; set; }

        [JsonProperty("usuario")]
        public string User { get; set; }

        public RequestApiBase()
        {
            Guid = Guid.NewGuid();
        }
    }
}
