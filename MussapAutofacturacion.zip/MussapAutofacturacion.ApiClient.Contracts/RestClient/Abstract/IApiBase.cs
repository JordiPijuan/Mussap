﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.RestClient.Abstract
{
    public interface IApiBase
    {
        Guid Guid { get; set; }
        int Company { get; set; }
        int Department { get; set; }
    }
}
