﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.RestClient.Abstract
{
    public abstract class ApiBase : IApiBase
    {
        [JsonIgnore]
        public Guid Guid { get; set; }

        [JsonProperty("empresa")]
        public int Company { get; set; }

        [JsonProperty("ramo")]
        public int Department { get; set; }
    }
}
