﻿using MussapAutofacturacion.ApiClient.Contracts.RestClient.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.RestClient
{
    public interface IApiResponse : IApiBase
    {
        short Year { get; set; }
        int SinisterCode { get; set; }
        string State { get; set; }
        string IncidenceCode { get; set; }
        string ErrorDescription { get; set; }
        DateTime ResponseDate { get; set; }
        RestResponseDto RestResponse { get; set; }
    }
}
