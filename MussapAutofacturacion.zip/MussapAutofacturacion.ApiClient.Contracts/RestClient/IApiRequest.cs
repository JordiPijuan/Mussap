﻿using MussapAutofacturacion.ApiClient.Contracts.RestClient.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.RestClient
{
    public interface IApiRequest : IApiBase
    {
        long CaseId { get; set; }
        int SummaryNu { get; set; }
        int SummaryTypeId { get; set; }
        long ShipmentId { get; set; }
        int? CaseTypeId { get; set; }
        string User { get; set; }
        string Endpoint { get; }
    }
}
