﻿using MussapAutofacturacion.ApiClient.Contracts.RestClient.Error;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.RestClient
{
    public class RestResponseDto
    {
        public HttpStatusCode StatusCode { get; set; }
        public string StatusDescription { get; set; }
        public string Content { get; set; }
        public Uri ResponseUri { get; set; }
        public string ErrorMessage { get; set; }
        public Exception ErrorException { get; set; }
        public ErrorContent ErrorContent { get; set; }
        public bool IsSuccessful { get; set; }
    }
}
