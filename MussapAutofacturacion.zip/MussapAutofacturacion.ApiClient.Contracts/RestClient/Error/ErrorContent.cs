﻿using MussapAutofacturacion.ApiClient.Contracts.RestClient.Abstract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.RestClient.Error
{
    public class ErrorResponse : ApiBase, IApiResponse
    {
        [JsonIgnore]
        public RestResponseDto RestResponse { get; set; }

        [JsonIgnore]
        public DateTime ResponseDate { get; set; }

        [JsonProperty("anio")]
        public short Year { get; set; }

        [JsonProperty("codSiniestro")]
        public int SinisterCode { get; set; }

        [JsonProperty("estado")]
        public string State { get; set; }

        [JsonProperty("codIncidencia")]
        public string IncidenceCode { get; set; }

        [JsonProperty("descripcionError")]
        public string ErrorDescription { get; set; }
        
    }

    public class ErrorContent
    {
        [JsonProperty("error")]
        public ErrorResponse ErrorResponse { get; set; }
    }
}
