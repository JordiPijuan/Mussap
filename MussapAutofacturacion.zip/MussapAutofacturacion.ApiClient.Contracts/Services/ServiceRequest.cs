﻿using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using MussapAutofacturacion.ApiClient.Contracts.RestClient.Abstract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.Services
{
    public class ServiceRequest : RequestApiBase, IApiRequest
    {
        [JsonProperty("xmlDocument")]
        public string Document { get; set; }
    }
}
