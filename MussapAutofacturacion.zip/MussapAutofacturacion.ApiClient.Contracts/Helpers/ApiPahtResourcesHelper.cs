﻿using MussapAutofacturacion.ApiClient.Contracts.Attributes;
using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using MussapAutofacturacion.ApiClient.Contracts.Services;
using MussapAutofacturacion.Common.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static MussapAutofacturacion.ApiClient.Contracts.Constants.Constants;

namespace MussapAutofacturacion.ApiClient.Contracts.Helpers
{
    public class ApiPahtResourcesHelper
    {
        const string ResourcePathNotFound = "Resource path not found.";
        const string ResourcePathNullOrEmpty = "Resource path is null or empty.";

        private static readonly IDictionary<Type, string> _apiPahtResources = new Dictionary<Type, string>()
        {
            
             { typeof(ServiceRequest), Endpoints.Services },
         
        };

        public static string GetResourcePath<TRequest>(TRequest request)
            where TRequest : IApiRequest
        {
            if (!_apiPahtResources.TryGetValue(request.GetType(), out string resourcePath))
            {
                throw new ApiClientException(ResourcePathNotFound);
            }

            ValidateResourcePath(resourcePath);

            var parametrizedUrlAttribute = request.GetType()
                .GetCustomAttribute<ParametrizedUrlAttribute>();

            if (parametrizedUrlAttribute != null)
            {
                resourcePath = parametrizedUrlAttribute.FormatUrl(resourcePath, request);
            }

            return resourcePath;
        }

        private static void ValidateResourcePath(string resourcePath)
        {
            if (string.IsNullOrEmpty(resourcePath))
            {
                throw new ApiClientException(ResourcePathNullOrEmpty);
            }
        }
    }
}
