﻿using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Contracts.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class ParametrizedUrlAttribute : Attribute
    {
        public string PropertyName { get; set; }
        public (string urlTag, string propertyName)[] UrlParameters { get; set; }

        public ParametrizedUrlAttribute(string propertyName)
            => PropertyName = propertyName;

        public ParametrizedUrlAttribute((string urlTag, string propertyName)[] urlParameters)
            => UrlParameters = urlParameters;

        public string FormatUrl(string resourcePath, IApiRequest request)
        {
            if (PropertyName != null)
            {
                var propertyValue = request
                    .GetType()
                    .GetProperty(PropertyName)
                    .GetValue(request, null);

                return string.Format(resourcePath, propertyValue.ToString());
            }
            else if (UrlParameters.Any())
            {
                throw new NotImplementedException("UrlParameters usage not implemented.");
            }

            throw new ArgumentException("Error using the ParametrizedUrlAttribute.");
        }
    }
}
