﻿using System;
using System.Collections.Concurrent;

namespace MussapAutofacturacion.Common
{
    public class ApiManagement
    {
        public static bool ApiPostEnabled = true;
        public static object ApiRunLock = new object();
        public static DateTime? LastSendedMailAcquiringTokenDate = null;
        public static long FirstCaseIdToHandle = 0;
        public static long? ForceUniqueCaseId = null;
        public static bool ForceSendAll = false;
        public static bool EfLoggerProviderEnabled = false;        
        public static int AdtCasesToSendTakeCount = 200;        

        public static ConcurrentDictionary<string, (DateTime date, string message)> FailedProcesses 
            = new ConcurrentDictionary<string, (DateTime date, string message)>();

        public static void AddFailedProcess(string processName, DateTime date, string message) 
            => FailedProcesses.AddOrUpdate(processName, (date, message), (key, oldValue) => (date, message));

        public static void RemoveFailedProcess(string processName)
            => FailedProcesses.TryRemove(processName, out var value);
    }
}
