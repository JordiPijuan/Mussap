﻿using System;

namespace MussapAutofacturacion.Common.Attributes
{
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class StringValueAttribute : Attribute
    {
        public string Value { get; private set; }
       
        public StringValueAttribute(string value)
        {
            Value = value;
        }
    }
}
