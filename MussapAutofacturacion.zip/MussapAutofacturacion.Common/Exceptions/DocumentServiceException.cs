﻿using System;

namespace MussapAutofacturacion.Common.Exceptions
{
    public class DocumentServiceException : Exception
    {
        public DocumentServiceException(string message)
            : base(message)
        {
        }

        public DocumentServiceException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
