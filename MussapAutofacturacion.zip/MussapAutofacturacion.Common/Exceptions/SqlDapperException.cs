﻿using System;

namespace MussapAutofacturacion.Common.Exceptions
{
    public class SqlDapperException : Exception
    {
        public SqlDapperException(string message)
            : base(message)
        {
        }

        public SqlDapperException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
