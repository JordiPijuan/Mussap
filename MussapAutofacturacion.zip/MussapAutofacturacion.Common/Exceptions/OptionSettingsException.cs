﻿using System;

namespace MussapAutofacturacion.Common.Exceptions
{
    public class OptionSettingsException : Exception
    {
        public OptionSettingsException(Type optionsType, Exception innerException)
            : base($"Failed loading option settings of type {optionsType.Name}", innerException)
        {
        }
    }
}
