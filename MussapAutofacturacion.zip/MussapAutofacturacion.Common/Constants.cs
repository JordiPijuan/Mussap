﻿using System;
using MussapAutofacturacion.Common.Enums;

namespace MussapAutofacturacion.Common
{
    public class Constants
    {
        public class Headers
        {
            public const string ContentType = "Content-Type";
            public const string Authorization = "authorization";
            public const string XIbmClientId = "x-ibm-client-id";
            public const string CacheControl = "Cache-Control";

            public class Values
            {
                public const string ApplicationJson = "application/json";
                public const string ApplicationUrlEncoded = "application/x-www-form-urlencoded";
                public const string MultiPartFormData = "multipart/form-data; boundary=1234567";
                public const string NoCache = "no-cache";
                public static string BearerToken(string token) => $"Bearer {token}";
                public static string BasicToken(string token) => $"Basic {token}";
            }
        }

 

        public class Endpoints
        {
        
        }

  


    }
}
