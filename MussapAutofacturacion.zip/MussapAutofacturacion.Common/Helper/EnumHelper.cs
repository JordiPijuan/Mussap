﻿using System;
using System.Linq;
using MussapAutofacturacion.Common.Extensions;

namespace MussapAutofacturacion.Common.Helper
{
    public class EnumHelper
    {
        public static TEnum GetEnumByStringValue<TEnum>(string stringValue)
            where TEnum : Enum
            => Enum
                .GetValues(typeof(TEnum))
                .Cast<TEnum>()
                .SingleOrDefault(e => e.GetStringValue() == stringValue);
    }
}
