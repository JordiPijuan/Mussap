﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace MussapAutofacturacion.Common.Helper
{
    public static class StringHelper
    {
        private static Regex _compiledUnicodeRegex = new Regex(@"[^\u0020-\u00FF]", RegexOptions.Compiled);

        public static string StripUnicodeCharactersFromString(this string inputValue)
        {
            return _compiledUnicodeRegex.Replace(inputValue, String.Empty);
        }
    }
}
