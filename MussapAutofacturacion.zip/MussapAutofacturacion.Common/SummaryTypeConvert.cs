﻿using System;
using System.Collections.Generic;
using MussapAutofacturacion.Common.Enums;
using MussapAutofacturacion.Common.Extensions;

namespace MussapAutofacturacion.Common
{
    public class SummaryTypeConvert
    {
        private static IDictionary<SummaryTypes, Lazy<SummaryTypeData>> _summaryTypesDataDictionary = new Dictionary<SummaryTypes, Lazy<SummaryTypeData>>
        {
            { SummaryTypes.CERRECAPE, new Lazy<SummaryTypeData>(() => new SummaryTypeData(7, "A", "00")) },
            { SummaryTypes.CONFIRM, new Lazy<SummaryTypeData>(() => new SummaryTypeData(1, "A", "00")) },

            { SummaryTypes.PROVIDER, new Lazy<SummaryTypeData>(() => new SummaryTypeData(1, "A", "00")) },
            { SummaryTypes.PRVREJECT, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.InclusionComentario.Value())) },
            { SummaryTypes.PRVCANCEL, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.InclusionComentario.Value())) },
            { SummaryTypes.PRVASIGN, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Anulacion.Value())) },
            { SummaryTypes.PRVENDED, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Cierre.Value())) },
            { SummaryTypes.PRVAPPSCH, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Reapertura.Value())) },
            { SummaryTypes.PRVAPPCON, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Reapertura.Value())) },
            { SummaryTypes.PRVAPPCAN, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Reapertura.Value())) },
            { SummaryTypes.PRVSTDBY, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Reapertura.Value())) },
            //{ SummaryTypes.EXPNEWPER, new Lazy<SummaryTypeData>(() => new SummaryTypeData(1, "A", "00")) },
            { SummaryTypes.PAGO, new Lazy<SummaryTypeData>(() => new SummaryTypeData(3, "M", ModifTypes.Cierre.Value())) },
            { SummaryTypes.EXPANUL, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Anulacion.Value())) },
            
            { SummaryTypes.NOTE, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.InclusionComentario.Value())) },
            { SummaryTypes.EXPNEW, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Reapertura.Value())) },
            { SummaryTypes.TRACE, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.InclusionComentario.Value())) },
            { SummaryTypes.REACURSO, new Lazy<SummaryTypeData>(() => new SummaryTypeData(6, "M", "00")) },
            { SummaryTypes.CERINDEM, new Lazy<SummaryTypeData>(() => new SummaryTypeData(5, "M", "00")) },
            { SummaryTypes.CERTRBFIN, new Lazy<SummaryTypeData>(() => new SummaryTypeData(5, "M", "00")) },
            { SummaryTypes.CERRECDOM, new Lazy<SummaryTypeData>(() => new SummaryTypeData(2, "M", "00")) },
            { SummaryTypes.REACONTA, new Lazy<SummaryTypeData>(() => new SummaryTypeData(6, "M", "00")) },
            { SummaryTypes.STANDBY, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "24")) },
            { SummaryTypes.EXPNEWPER, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Reapertura.Value())) },
            { SummaryTypes.NUEGAR, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "08")) },
            { SummaryTypes.BORGAR, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "08")) },
            { SummaryTypes.MCONTACT, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "06")) },
            { SummaryTypes.COMPLAINT, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.AltaReclamacion.Value())) },
            { SummaryTypes.MIR, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Anulacion.Value())) },
            { SummaryTypes.INDBILL, new Lazy<SummaryTypeData>(() => new SummaryTypeData(8, "A", "00")) },
            { SummaryTypes.TELLMOD, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.AltaReclamacion.Value())) },
            { SummaryTypes.CAUSPERJ, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "07")) },
            { SummaryTypes.PERJCAUS, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Reapertura.Value())) },
            { SummaryTypes.COPPLAINT, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Cierre.Value())) },
            { SummaryTypes.UPDCOMPLA, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.InclusionComentario.Value())) },
            { SummaryTypes.CALIDAOK, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "14")) },
            { SummaryTypes.CALIDAKO, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "14")) },
            { SummaryTypes.TRACEEND, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "32")) },
            { SummaryTypes.CHANGEELE, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "23")) },
            { SummaryTypes.CHANGEJUD, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", "22")) },
            { SummaryTypes.ANUCOMPLA, new Lazy<SummaryTypeData>(() => new SummaryTypeData(4, "M", ModifTypes.Anulacion.Value())) },
        };

        public static (int sendType, string sendModo, string modifType) GetSummaryTypeData(SummaryTypes summaryType)
        {
            if (!_summaryTypesDataDictionary.TryGetValue(summaryType, out var data))
                throw new ArgumentOutOfRangeException($"SummaryTypeConvert doesn't have a convertion for the SummaryType: {(int)summaryType}-{summaryType.ToString()}");

            return (
                sendType: data.Value.SendType, 
                sendModo: data.Value.SendModo, 
                modifType: data.Value.ModifType
                );
        }

        public static bool IsSolpercia(SummaryTypes summaryType)
        {
            var (sendType, sendModo, modifType) = GetSummaryTypeData(summaryType);
            return sendType == 4 && sendModo == "M" && modifType == "02";
        }

        private class SummaryTypeData
        {
            public int SendType { get; set; }
            public string SendModo { get; set; }
            public string ModifType { get; set; }

            public SummaryTypeData(int sendType, string sendModo, string modifType)
            {
                SendType = sendType;
                SendModo = sendModo;
                ModifType = modifType;
            }
        }
    }
}
