﻿using Microsoft.Extensions.Configuration;

namespace MussapAutofacturacion.Common.ConfigurationOptions
{
    public sealed class OptionsConfiguration<TSettings> : OptionsBase<TSettings>
    where TSettings : new()
    {
        public OptionsConfiguration(IConfiguration configuration) : base(configuration) { }
    }
}
