﻿namespace MussapAutofacturacion.Common.ConfigurationOptions.Implementations
{
    public class ApiRestSettings
    {
        public string UrlBase { get; set; }
        //public string ClientId { get; set; }
        public string User { get; set; }
    }
}
