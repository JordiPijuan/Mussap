﻿namespace MussapAutofacturacion.Common.ConfigurationOptions.Implementations
{
    public class FileWriterSettings
    {
        public string DirectoryRootPath { get; set; }
        public string ExpedientsFolderName { get; set; }
        public string RequestFolder { get; set; }
        public string ResponseFolder { get; set; }
        public string RequestExtension { get; set; }
        public string ResponseExtension { get; set; }
    }
}
