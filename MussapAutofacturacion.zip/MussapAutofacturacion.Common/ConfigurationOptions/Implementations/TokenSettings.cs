﻿namespace MussapAutofacturacion.Common.ConfigurationOptions.Implementations
{
    public class TokenSettings
    {
        public string UrlBase { get; set; }
        public string UrlOauthTokenPath { get; set; }
        //public string Token { get; set; }
        //public string Username { get; set; }
        //public string Password { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
    }
}
