﻿namespace MussapAutofacturacion.Common.ConfigurationOptions.Implementations
{
    public class HostedServicesSettings
    {
        public string BaseUrl { get; set; }
        public int Port { get; set; }
        public string ApiScheduledProcessesPath { get; set; }
        public string ApiServicesPath { get; set; }        
      
        public ApiStatusCheckerSettings ApiStatusCheckerSettings { get; set; }

        public DocumentsServiceProcessSettings DocumentsServiceProcessSettings { get; set; }
    }

    public abstract class ProcessSettingsBase
    {
        public string RunPath { get; set; }
        public string CronExpression { get; set; }
        public bool Enabled { get; set; }
    }



    public class ApiStatusCheckerSettings : ProcessSettingsBase
    {
    }
    public class DocumentsServiceProcessSettings : ProcessSettingsBase
    {
        public string MussapAutofacturacionSoapUrl { get; set; }
        public string MussapAutofacturacionSoapUsername { get; set; }
        public string MussapAutofacturacionSoapPassword { get; set; }
    }
}
