﻿namespace MussapAutofacturacion.Common.ConfigurationOptions.Contracts
{
    public interface IConfigOptions<TSettings>
    {
        TSettings Value { get; set; }
    }
}
