﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Extensions.Configuration;
using MussapAutofacturacion.Common.ConfigurationOptions.Contracts;
using MussapAutofacturacion.Common.Exceptions;

namespace MussapAutofacturacion.Common.ConfigurationOptions
{
    public abstract class OptionsBase<TSettings> : IConfigOptions<TSettings> 
        where TSettings : new()
    {
        public TSettings Value { get; set; }

        public OptionsBase()
        {
            Value = GetSettings();
        }

        public OptionsBase(IConfiguration configuration)
        {
            Value = GetSettings(configuration);
        }

        public TSettings GetSettings(IConfiguration configuration = null)
        {
            var result = new TSettings();
            var sectionName = typeof(TSettings).Name;

            try
            {
                BindSection(result, sectionName, configuration);
            }
            catch (Exception ex)
            {
                throw new OptionSettingsException(typeof(TSettings), ex);
            }

            return result;
        }

        private void BindSection(TSettings result, string sectionName, IConfiguration configuration = null)
        {
            if(configuration is null)
            {
                BindSectionConfigurationManager(result, sectionName);
            }
            else
            {
                BindSectionConfiguration(result, sectionName, configuration);
            }
        }

        private static void BindSectionConfigurationManager(TSettings result, string sectionName)
        {
            var properties = typeof(TSettings).GetProperties();
            var section = ConfigurationManager.GetSection(sectionName) as NameValueCollection;

            foreach (var property in properties)
            {
                var value = section[property.Name];
                object castedValue = Convert.ChangeType(value, property.PropertyType);
                property.SetValue(result, castedValue);
            }
        }

        private static void BindSectionConfiguration(TSettings result, string sectionName, IConfiguration configuration)
        {
            var properties = typeof(TSettings).GetProperties();
            var section = configuration.GetSection(sectionName);

            foreach (var property in properties)
            {
                var value = section[property.Name];
                if(value is null)
                {
                    try
                    {
                        var propertyInstance = Activator.CreateInstance(property.PropertyType);
                        BindChildrenSectionConfiguration(propertyInstance, sectionName, property.Name, configuration);

                        object castedValue = Convert.ChangeType(propertyInstance, property.PropertyType);
                        property.SetValue(result, castedValue);
                    }
                    catch (Exception) {}
                }
                else
                {
                    object castedValue = Convert.ChangeType(value, property.PropertyType);
                    property.SetValue(result, castedValue);
                }

            }
        }

        private static void BindChildrenSectionConfiguration(object result, string fatherSectionName, string sectionName, IConfiguration configuration)
        {
            var properties = result.GetType().GetProperties();
            var section = configuration.GetSection($"{fatherSectionName}:{sectionName}");

            foreach (var property in properties)
            {
                var value = section[property.Name];
                object castedValue = Convert.ChangeType(value, property.PropertyType);
                property.SetValue(result, castedValue);
            }
        }
    }
}
