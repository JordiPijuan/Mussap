﻿namespace MussapAutofacturacion.Common.ConfigurationOptions
{
    public sealed class OptionsConfigurationManager<TSettings> : OptionsBase<TSettings>
        where TSettings : new()
    {
        public OptionsConfigurationManager() : base() {}
    }
}
