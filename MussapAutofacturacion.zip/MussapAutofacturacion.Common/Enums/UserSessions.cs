﻿namespace MussapAutofacturacion.Common.Enums
{
    public enum UserSessions
    {
        Default = 1,
    }
}
