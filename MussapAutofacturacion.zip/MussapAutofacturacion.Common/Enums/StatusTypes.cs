﻿namespace MussapAutofacturacion.Common.Enums
{
    public enum StatusTypes
    {
        CERPAGADO = 36,
        PRVENCAN = 314,
        OPISANNCO = 316,
        CompanyRequestsSinisterClosing = 4019
    }
}
