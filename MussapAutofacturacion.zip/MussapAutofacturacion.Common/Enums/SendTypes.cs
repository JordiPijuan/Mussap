﻿namespace MussapAutofacturacion.Common.Enums
{
    public enum SendTypes
    {
        Unknown = 4,
        CierreSiniestro = 5
    }
}
