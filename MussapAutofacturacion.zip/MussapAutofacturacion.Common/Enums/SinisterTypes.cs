﻿namespace MussapAutofacturacion.Common.Enums
{
    public enum SinisterTypes
    {
        Mixto = 1,
        Indemnizable = 2,
        Reparable = 3
    }
}
