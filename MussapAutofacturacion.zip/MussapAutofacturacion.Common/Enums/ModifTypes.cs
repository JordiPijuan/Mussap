﻿namespace MussapAutofacturacion.Common.Enums
{
    public enum ModifTypes
    {
        AltaReclamacion = 1,
        InclusionComentario = 2,
        Cierre = 3,
        Reapertura = 4,
        Anulacion = 5,
        FinEncuesta = 14,
        ResponseSucesoPerito = 32
    }
}
