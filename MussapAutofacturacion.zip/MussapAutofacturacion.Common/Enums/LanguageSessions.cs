﻿namespace MussapAutofacturacion.Common.Enums
{
    public enum LanguageSessions
    {
        ES = 1
    }
}
