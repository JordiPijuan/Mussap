﻿namespace MussapAutofacturacion.Common.Enums
{
    public enum SummaryTypes
    {
        PROVIDER = 3,
        PRVREJECT = 8,
        PRVCANCEL = 9,
        PRVASIGN = 10,
        PRVENDED = 11,
        PRVAPPSCH = 12,
        PRVAPPCON = 13,
        PRVAPPCAN = 14,
        PRVSTDBY = 16,
        NOTE = 17,
        EXPNEW = 18,
        TRACE = 29,
        REACURSO = 36,
        CERINDEM = 38,
        CERTRBFIN = 39,
        CERTRFYIN = 40,
        CERPAGADO = 43,
        CERRECAPE = 45,
        CERRECDOM = 46,
        REACONTA = 47,
        STANDBY = 55,
        EXPNEWPER = 57,
        NUEGAR = 64,
        BORGAR = 66,
        PAGO = 70,
        MCONTACT = 74,
        CONFIRM = 75,
        COMPLAINT = 76,
        MIR = 77,
        INDBILL = 79,
        TELLMOD = 90,
        CAUSPERJ = 93,
        PERJCAUS = 94,
        COPPLAINT = 96,
        UPDCOMPLA = 102,
        CALIDAOK = 104,
        CALIDAKO = 105,
        EXPANUL = 106,
        TRACEEND = 118,
        CHANGEELE = 119,
        CHANGEJUD = 120,
        PAGOREFAC = 122,
        ANUCOMPLA = 124
    }

    public enum RecobroSummaryTypes
    {
        NEWCASE = 1,
        ADDCONTAC = 12,
        NUEASEG = 34
    }
}
