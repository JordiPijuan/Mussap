﻿namespace MussapAutofacturacion.Common.Enums
{
    public enum MovementTypes
    {
        Alta = 1,
        RechazoDomicilio = 2,
        ModificacionSiniestro = 4,
        Cierre = 5,
        Reapertura = 6,
        RechazoApertura = 7,
        Nulo = 8
    }
}
