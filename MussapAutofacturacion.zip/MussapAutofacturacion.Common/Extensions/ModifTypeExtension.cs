﻿using MussapAutofacturacion.Common.Enums;

namespace MussapAutofacturacion.Common.Extensions
{
    public static class ModifTypeExtension
    {
        public static string Value(this ModifTypes modifType) => ((int)modifType).ToString("00");
    }
}
