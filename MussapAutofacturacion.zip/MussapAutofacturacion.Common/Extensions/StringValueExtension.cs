﻿using System;
using System.Reflection;
using MussapAutofacturacion.Common.Attributes;

namespace MussapAutofacturacion.Common.Extensions
{
    public static class StringValueExtension
    {
        public static string GetStringValue(this Enum value)
        {
            var fieldInfo = value.GetType().GetField(value.ToString());

            var attribute = fieldInfo?.GetCustomAttribute(typeof(StringValueAttribute)) as StringValueAttribute;

            return (attribute is null) 
                ? value.ToString()
                : attribute.Value;
        }
    }
}
