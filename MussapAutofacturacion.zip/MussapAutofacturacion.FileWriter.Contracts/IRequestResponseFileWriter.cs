﻿using System;
using System.Net;

namespace MussapAutofacturacion.FileWriter.Contracts
{
    public interface IRequestResponseFileWriter
    {
        (string request, string response) GetAbsolutePaths(long caseId, int summaryNu, string endpoint, HttpStatusCode statusCode, DateTime date);
        //string GetFileName(long caseId, int summaryNu, string endpoint, HttpStatusCode statusCode);
        //(string request, string response) GetDirectoryPaths(long caseId, int summaryNu, string endpoint, HttpStatusCode statusCode);
        //(string request, string response) GetFileExtensions();
        void Write(long caseId, int summaryNu, string endpoint, string requestContents, string responseContents, HttpStatusCode statusCode, DateTime date);
    }
}
