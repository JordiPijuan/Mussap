﻿namespace MussapAutofacturacion.FileWriter.Contracts
{
    public interface IFileWriter
    {
        void Write(string directoryPath, string fileName, string extension, string contents);
    }
}
