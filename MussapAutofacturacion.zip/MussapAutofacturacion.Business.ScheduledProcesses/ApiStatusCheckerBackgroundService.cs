﻿using Cronos;
using Microsoft.Extensions.DependencyInjection;
using MussapAutofacturacion.Common.ConfigurationOptions.Contracts;
using MussapAutofacturacion.Common.ConfigurationOptions.Implementations;
using MussapAutofacturacion.Logger.Contracts;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Business.ScheduledProcesses
{
    public class ApiStatusCheckerBackgroundService : BackgroundServiceBase
    {
        private readonly IServiceScopeFactory _serviceScopeFactory;
        private readonly ApiStatusCheckerSettings _processSettings;

        public ApiStatusCheckerBackgroundService(IServiceScopeFactory serviceScopeFactory, IConfigOptions<HostedServicesSettings> hostedServicesSettingOptions)
        {
            HostedServicesSettings = hostedServicesSettingOptions.Value;
            _processSettings = HostedServicesSettings.ApiStatusCheckerSettings;

            var cronExpression = _processSettings.CronExpression;

            Cron = CronExpression.Parse("* * * * *"); //CronExpression.Parse(cronExpression);
            NextRun = Cron.GetNextOccurrence(DateTimeOffset.Now, TimeZoneInfo.Local);
            _serviceScopeFactory = serviceScopeFactory;
        }

        protected override void Process()
        {
            using (var scope = _serviceScopeFactory.CreateScope())
            {
                var log = scope.ServiceProvider.GetService<ILog<ApiStatusCheckerBackgroundService>>();

                var baseUrl = HostedServicesSettings.BaseUrl;
                var port = HostedServicesSettings.Port;

                if (_processSettings.Enabled)
                {
                    var runProcessPath = _processSettings.RunPath;
                    var url = $"{baseUrl}:{port}{runProcessPath}";

                    var response = ExecutePost(url);
                    var logMessage = $"BackgroundService - Petition to '{url}' with response '{(int)response.StatusCode}-{response.StatusCode.ToString()}'";

                    if (!response.IsSuccessful)
                    {
                        log.Error(logMessage);
                    }
                    else
                    {
                        log.Debug(logMessage);

                        var services = JsonConvert.DeserializeObject<int>(response.Content);

                    }
                }
            }
        }
    }
}
