﻿using Cronos;
using Microsoft.Extensions.DependencyInjection;
using MussapAutofacturacion.Common.ConfigurationOptions.Contracts;
using MussapAutofacturacion.Common.ConfigurationOptions.Implementations;
using MussapAutofacturacion.Logger.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Business.ScheduledProcesses
{
    public class DocumentsBackgroundService : BackgroundServiceBase
    {
        private readonly IServiceScopeFactory _serviceScopeFactory;
        private readonly DocumentsServiceProcessSettings _processSettings;

        public DocumentsBackgroundService(IServiceScopeFactory serviceScopeFactory, IConfigOptions<HostedServicesSettings> hostedServicesSettingOptions)
        {
            HostedServicesSettings = hostedServicesSettingOptions.Value;
            _processSettings = HostedServicesSettings.DocumentsServiceProcessSettings;

            var cronExpression = _processSettings.CronExpression;

            Cron = CronExpression.Parse("* * * * *" /* cronExpression */);
            NextRun = Cron.GetNextOccurrence(DateTimeOffset.Now, TimeZoneInfo.Local);
            _serviceScopeFactory = serviceScopeFactory;
        }

        protected override void Process()
        {
            using (var scope = _serviceScopeFactory.CreateScope())
            {
                var log = scope.ServiceProvider.GetService<ILog<DocumentsBackgroundService>>();

                var baseUrl = HostedServicesSettings.BaseUrl;
                var port = HostedServicesSettings.Port;
                var apiServicesPath = HostedServicesSettings.ApiServicesPath;

                if (_processSettings.Enabled)
                {
                    var runProcessPath = _processSettings.RunPath;
                    var url = $"{baseUrl}:{port}{apiServicesPath}{runProcessPath}";

                    var response = ExecutePost(url);

                    log.Debug($"BackgroundService - Petition to '{url}' with response '{(int)response.StatusCode}-{response.StatusCode.ToString()}'");
                }
            }
        }
    }
}
