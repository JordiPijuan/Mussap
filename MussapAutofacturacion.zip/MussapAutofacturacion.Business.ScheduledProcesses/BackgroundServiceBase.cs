﻿using Cronos;
using Microsoft.Extensions.Hosting;
using MussapAutofacturacion.Common.ConfigurationOptions.Implementations;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Business.ScheduledProcesses
{
    public abstract class BackgroundServiceBase : BackgroundService
    {
        protected HostedServicesSettings HostedServicesSettings;
        protected CronExpression Cron;
        protected DateTimeOffset? NextRun;

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            do
            {
                var now = DateTimeOffset.Now;

                if (now > NextRun)
                {
                    Process();
                    NextRun = Cron.GetNextOccurrence(now, TimeZoneInfo.Local);
                }
                await Task.Delay(5000, stoppingToken); //5 seconds delay
            }
            while (!stoppingToken.IsCancellationRequested);
        }

        protected abstract void Process();

        public IRestResponse ExecutePost(string url)
        {
            var client = new RestClient(url)
            {
                RemoteCertificateValidationCallback = delegate { return true; }
            };
            var request = new RestRequest(Method.POST);

            IRestResponse response = client.Execute(request);
            return response;
        }
    }
}
