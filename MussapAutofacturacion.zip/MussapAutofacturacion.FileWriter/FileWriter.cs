﻿using System.IO;
using MussapAutofacturacion.FileWriter.Contracts;

namespace MussapAutofacturacion.FileWriter
{
    public sealed class FileWriter : IFileWriter
    {
        public void Write(string directoryPath, string fileName, string extension, string contents)
        {
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
            File.WriteAllText($"{directoryPath}\\{fileName}.{extension}", contents);
        }
    }
}
