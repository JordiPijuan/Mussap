﻿using System;
using System.Net;
using MussapAutofacturacion.Common.ConfigurationOptions.Contracts;
using MussapAutofacturacion.Common.ConfigurationOptions.Implementations;
using MussapAutofacturacion.FileWriter.Contracts;

namespace MussapAutofacturacion.FileWriter
{
    public class RequestResponseFileWriter : IRequestResponseFileWriter
    {
        private readonly IFileWriter _fileWriter;
        private readonly FileWriterSettings _fileWriterSettings;

        public RequestResponseFileWriter(IFileWriter fileWriter, IConfigOptions<FileWriterSettings> fileWritterOptions)
        {
            _fileWriter = fileWriter;
            _fileWriterSettings = fileWritterOptions.Value;
        }

        public void Write(long caseId, int summaryNu, string endpoint, string requestContents, string responseContents, HttpStatusCode statusCode, DateTime date)
        {
            string fileName = ComposeFileName(caseId, summaryNu, endpoint, statusCode, date);

            var paths = GetDirectoryPaths(caseId, summaryNu, endpoint, statusCode);
            var extensions = GetFileExtensions();

            _fileWriter.Write(paths.request, fileName, extensions.request, requestContents);
            _fileWriter.Write(paths.response, fileName, extensions.response, responseContents);
        }

        public (string request, string response) GetAbsolutePaths(long caseId, int summaryNu, string endpoint, HttpStatusCode statusCode, DateTime date)
        {
            var paths = GetDirectoryPaths(caseId, summaryNu, endpoint, statusCode);
            var fileName = ComposeFileName(caseId, summaryNu, endpoint, statusCode, date);
            var extensions = GetFileExtensions();

            var requestAbsoutePath = $"{paths.request}\\{fileName}.{extensions.request}";

            var responseAbsolutePath = $"{paths.response}\\{fileName}.{extensions.response}";

            return (requestAbsoutePath, responseAbsolutePath);
        }

        //private string GetFileName(long caseId, int summaryNu, string endpoint, HttpStatusCode statusCode)
        //    => ComposeFileName(caseId, summaryNu, endpoint, statusCode);

        private static string ComposeFileName(long caseId, int summaryNu, string endpoint, HttpStatusCode statusCode, DateTime date) 
            => $"{date.ToString("yyyyMMddhhmmss")}.{caseId.ToString("00000000")}-{summaryNu.ToString("00000")}.{endpoint}-{(int)statusCode}-{statusCode.ToString()}";

        private (string request, string response) GetDirectoryPaths(long caseId, int summaryNu, string endpoint, HttpStatusCode statusCode)
        {
            var basePath = $"{_fileWriterSettings.DirectoryRootPath}\\{_fileWriterSettings.ExpedientsFolderName}\\{caseId}";
            var directoryPathRequest = $"{basePath}\\{_fileWriterSettings.RequestFolder}";
            var directoryPathResponse = $"{basePath}\\{_fileWriterSettings.ResponseFolder}";

            return (directoryPathRequest, directoryPathResponse);
        }

        private (string request, string response) GetFileExtensions()
            => (_fileWriterSettings.RequestExtension, _fileWriterSettings.ResponseExtension);
    }
}
