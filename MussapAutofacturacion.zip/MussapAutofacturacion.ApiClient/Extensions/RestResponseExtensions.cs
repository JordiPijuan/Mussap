﻿using AutoMapper;
using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using MussapAutofacturacion.ApiClient.Contracts.RestClient.Error;
using MussapAutofacturacion.ApiClient.Exceptions;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Extensions
{
    public static class RestResponseExtensions
    {
        //public static IRestResponse ValidateSuccessfulResponse(this IRestResponse response)
        //    => response.IsSuccessful
        //        ? response
        //        : ManageNotSuccessfulResponse(response);

        //private static IRestResponse ManageNotSuccessfulResponse(IRestResponse response)
        //{
            
        //    if (response.StatusCode == HttpStatusCode.Unauthorized)
        //    {
        //        throw new UnauthorizedException($"StatusCode: '{(int)response.StatusCode}-{response.StatusCode.ToString()}', Content: '{response.Content}'.");
        //    }

        //    RestResponseDto responseDto;
        //    try
        //    {
        //        responseDto = Mapper.Map<RestResponseDto>(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception($"Failed trying to Map the {nameof(IRestResponse)} to {nameof(RestResponseDto)}. ErrorMessage: '{response.ErrorMessage}', Content: '{response.Content}', StatusCode: '{(int)response.StatusCode}-{response.StatusCode.ToString()}'.", ex);
        //    }
        //    throw new RestResponseException(Mapper.Map<RestResponseDto>(response));
        //}

        //public static IApiResponse MapResponse<TResponse>(this Models.IRestApiResponse response)
        //    where TResponse : IApiResponse
        //{
        //    try
        //    {
        //        var apiResponse = response.IsSuccessful
        //            ? (IApiResponse)JsonConvert.DeserializeObject<TResponse>(response.Content)
        //            : JsonConvert.DeserializeObject<ErrorContent>(response.Content)
        //                            .ErrorResponse;

        //        var restResponseDto = Mapper.Map<RestResponseDto>(response);
        //        apiResponse.RestResponse = restResponseDto;
        //        apiResponse.ResponseDate = DateTime.Now;

        //        return apiResponse;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new JsonFormatException(response.Content, response.StatusCode, ex);
        //    }
        //}

        //public static IApiResponse AssignGuid(this IApiResponse response, IApiRequest request)
        //{
        //    response.Guid = request.Guid;

        //    return response;
        //}
    }
}
