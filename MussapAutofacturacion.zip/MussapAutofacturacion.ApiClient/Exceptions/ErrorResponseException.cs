﻿using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using MussapAutofacturacion.ApiClient.Contracts.RestClient.Error;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Exceptions
{
    public class ErrorResponseException : Exception
    {
        public ErrorResponse Response { get; set; }
        public IApiRequest Request { get; set; }

        public ErrorResponseException(IApiRequest request, ErrorResponse response)
            : base($"Error response for CaseId: '{request.CaseId}' and SummaryNu: '{request.SummaryNu}'. Response: '{JsonConvert.SerializeObject(response)}'")
        {
            Request = request;
            Response = response;
        }
    }
}
