﻿using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Exceptions
{
    public class RestResponseException : Exception
    {
        public RestResponseDto RestResponse { get; set; }
        public IApiResponse Response { get; set; }
        public IApiRequest Request { get; set; }

        public RestResponseException(RestResponseDto restResponseDto)
            : base(restResponseDto.ErrorMessage, restResponseDto.ErrorException)
        {
            RestResponse = restResponseDto;
        }

        public RestResponseException(string errorMessage, IApiRequest request, IApiResponse response)
            : base(errorMessage)
        {
            Request = request;
            Response = response;
        }
    }
}
