﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Exceptions
{
    public class JsonFormatException : Exception
    {
        private const string ErrorMessage = "Impossible to deserialize the object: '{0}'.";

        public JsonFormatException(string json)
            : base(string.Format(ErrorMessage, json))
        {
        }

        public JsonFormatException(string json, Exception innerException)
            : base(string.Format(ErrorMessage, json), innerException)
        {
        }

        public JsonFormatException(string json, HttpStatusCode statusCode, Exception innerException)
            : base($"{(int)statusCode}:{statusCode.ToString()} - {string.Format(ErrorMessage, json)}", innerException)
        {
        }
    }
}
