﻿using MussapAutofacturacion.ApiClient.Contracts.Constants;
using MussapAutofacturacion.ApiClient.Contracts.Helpers;
using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using MussapAutofacturacion.ApiClient.Extensions;
using MussapAutofacturacion.ApiClient.Models;
using MussapAutofacturacion.Common.ConfigurationOptions.Contracts;
using MussapAutofacturacion.Common.ConfigurationOptions.Implementations;
using MussapAutofacturacion.FileWriter.Contracts;
using MussapAutofacturacion.Logger.Contracts;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.RestClient
{
    public class ApiRestClient : IApiRestClient
    {
        const string ResourcePathNotFound = "Resource path not found.";
        const string ResourcePathNullOrEmpty = "Resource path is null or empty.";
        private readonly object _lock = new object();

        private readonly ITokenHandler _tokenHandler;
        private readonly ApiRestSettings _apiRestSettings;
        private readonly TokenSettings _tokenSettings;
        private readonly IRequestResponseFileWriter _fileWriter;
        private readonly ILog<ApiRestClient> _logger;

        public ApiRestClient(
            ITokenHandler tokenHandler,
            IConfigOptions<ApiRestSettings> apiRestOptions,
            IConfigOptions<TokenSettings> tokenOptions,
            IRequestResponseFileWriter fileWriter,
            ILog<ApiRestClient> logger
            )
        {
            _tokenHandler = tokenHandler;
            _fileWriter = fileWriter;
            _logger = logger;
            _apiRestSettings = apiRestOptions.Value;
            _tokenSettings = tokenOptions.Value;
        }




        private IRestApiResponse ExecutePost(IApiRequest apiRequest, string resourcePath, string token)
        {
            IRestApiResponse response;

            var url = $"{_apiRestSettings.UrlBase}{resourcePath}";
            var clientId = _tokenSettings.ClientId;
            var bodyJson = JsonConvert.SerializeObject(apiRequest);

            var defaultHeaders = new List<(string name, string value)>
            {
                (Constants.Headers.XIbmClientId, clientId),
                (Constants.Headers.Authorization, Constants.Headers.Values.BearerToken(token)),
                (Constants.Headers.CacheControl, Constants.Headers.Values.NoCache)
            };

            _logger.Debug($"Sending to: '{url}' the json: '{bodyJson}'");

            if (apiRequest is IApiFileRequest apiFileRequest)
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    defaultHeaders.ForEach(h => httpClient.DefaultRequestHeaders.Add(h.name, h.value));

                    var byteArrayContent = new ByteArrayContent(apiFileRequest.File);

                    var httpResponseMessage = httpClient.PostAsync(url, new MultipartFormDataContent()
                    {
                        {new StringContent(bodyJson, Encoding.UTF8, Constants.Headers.Values.ApplicationJson), Constants.Parameters.DocumentJson},
                        {byteArrayContent, "\"file\"", apiFileRequest.FileName}
                    }).Result;

                    response = RestApiResponse.MapResponse(httpResponseMessage);
                }
            }
            else
            {
                var client = new RestSharp.RestClient($"{_apiRestSettings.UrlBase}{resourcePath}");
                client.RemoteCertificateValidationCallback = delegate { return true; };
                var request = new RestRequest(Method.POST);

                defaultHeaders.ForEach(h => request.AddHeader(h.name, h.value));
                request.AddHeader(Constants.Headers.ContentType, Constants.Headers.Values.ApplicationJson);
                request.AddParameter(Constants.Parameters.Undefined, bodyJson, ParameterType.RequestBody);

                response = RestApiResponse.MapResponse(client.Execute(request));
            }

            WriteRequestAndResponseToFile(apiRequest, bodyJson, response, resourcePath);

            return response;
        }

        private void WriteRequestAndResponseToFile(IApiRequest request, string requestJson, IRestApiResponse response, string resourcePath)
            => _fileWriter.Write(request.CaseId, request.SummaryNu, resourcePath.Trim('/').Replace('/', '%'), requestJson, response.Content, response.StatusCode, DateTime.Now);
    }
}
