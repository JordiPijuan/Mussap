﻿using AutoMapper;
using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using MussapAutofacturacion.ApiClient.Contracts.RestClient.Error;
using MussapAutofacturacion.ApiClient.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Mapping
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<IRestApiResponse, RestResponseDto>()
                    .ForMember(dest => dest.ErrorContent,
                        opts => opts.MapFrom(src => JsonConvert.DeserializeObject<ErrorContent>(src.Content)));
        }
    }
}
