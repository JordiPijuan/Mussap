﻿using MussapAutofacturacion.ApiClient.Contracts.Constants;
using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using MussapAutofacturacion.ApiClient.Extensions;
using MussapAutofacturacion.Common.ConfigurationOptions.Contracts;
using MussapAutofacturacion.Common.ConfigurationOptions.Implementations;
using MussapAutofacturacion.Logger.Contracts;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Models
{
    public class TokenHandler : ITokenHandler
    {
        const int ThresholdExpirationSeconds = 10;
        private Token _token;
        private readonly TokenSettings _tokenSettings;
        private readonly ILog<TokenHandler> _logger;
        private readonly object _lock = new object();

        public TokenHandler(IConfigOptions<TokenSettings> tokenOptions, ILog<TokenHandler> logger)
        {
            _tokenSettings = tokenOptions.Value;
            _logger = logger;
        }

        //public Token GetToken()
        //{
        //    lock (_lock)
        //    {
        //        if (!IsValidToken()) AcquireToken();

        //        return _token;
        //    }
        //}

        //private void AcquireToken()
        //{
        //    var keyValueParameters = new Dictionary<string, string>
        //    {
        //        //{ Constants.Parameters.Keys.Username, _tokenSettings.Username },
        //        //{ Constants.Parameters.Keys.Password, _tokenSettings.Password }
        //        { Constants.Parameters.Keys.ClientId, _tokenSettings.ClientId },
        //        { Constants.Parameters.Keys.ClientSecret, _tokenSettings.ClientSecret }
        //    };

        //    _logger.Debug($"Acquiring Token from Url: '{_tokenSettings.UrlBase}{_tokenSettings.UrlOauthTokenPath}'.");

        //    var client = new RestSharp.RestClient($"{_tokenSettings.UrlBase}{_tokenSettings.UrlOauthTokenPath}");
        //    var request = new RestRequest(Method.POST);

        //    //request.AddHeader(Constants.Headers.Authorization, Constants.Headers.Values.BasicToken(_tokenSettings.Token)) ;
        //    request.AddHeader(Constants.Headers.ContentType, Constants.Headers.Values.ApplicationUrlEncoded);
        //    request.AddParameter(Constants.Parameters.Undefined, string.Join("&", keyValueParameters.Select(kv => $"{kv.Key}={kv.Value}").ToArray()), ParameterType.RequestBody);
        //    client.RemoteCertificateValidationCallback = delegate { return true; };
        //    IRestResponse response;

        //    try
        //    {
        //        response = client
        //            .Execute(request)
        //            .ValidateSuccessfulResponse();
        //    }
        //    catch (Exception ex)
        //    {
        //        var errorMessage = $"Error Acquiring Token from URL: '{_tokenSettings.UrlBase}{_tokenSettings.UrlOauthTokenPath}'.";
        //        _logger.Error(errorMessage, ex);
              
        //        throw;
        //    }

        //    _token = JsonConvert.DeserializeObject<Token>(response.Content);
        //    _logger.Debug($"Token acquired from Url: '{_tokenSettings.UrlBase}{_tokenSettings.UrlOauthTokenPath}'.");
        //}

        private bool IsValidToken()
        {
            if (_token is null) return false;

            var expiresOn = _token.ConsentedOn + _token.ExpiresIn - ThresholdExpirationSeconds;

            return expiresOn > DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        }
    }
}
