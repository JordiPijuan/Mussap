﻿using MussapAutofacturacion.ApiClient.Contracts.RestClient;

namespace MussapAutofacturacion.ApiClient.RestClient
{
    public interface IApiFileRequest : IApiRequest
    {
        string Type { get; set; }
        string Description { get; set; }
        string FileName { get; set; }
        byte[] File { get; set; }
    }
}