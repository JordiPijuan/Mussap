﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Models
{
    public class RestApiResponse : IRestApiResponse
    {
        public static IRestApiResponse MapResponse(IRestResponse response) => new RestApiResponse(response);
        public static IRestApiResponse MapResponse(HttpResponseMessage response) => new RestApiResponse(response);

        private RestApiResponse(IRestResponse response)
        {
            Request = response.Request;
            ContentType = response.ContentType;
            ContentLength = response.ContentLength;
            ContentEncoding = response.ContentEncoding;
            Content = response.Content;
            StatusCode = response.StatusCode;

            IsSuccessful = response.IsSuccessful;

            StatusDescription = response.StatusDescription;
            RawBytes = response.RawBytes;
            ResponseUri = response.ResponseUri;
            Server = response.Server;

            ResponseStatus = response.ResponseStatus;
            ErrorMessage = response.ErrorMessage;
            ErrorException = response.ErrorException;
            ProtocolVersion = response.ProtocolVersion;
        }

        private RestApiResponse(HttpResponseMessage response)
        {
            Content = response.Content.ReadAsStringAsync().Result;
            StatusCode = response.StatusCode;

            IsSuccessful = response.IsSuccessStatusCode;
        }

        public IRestRequest Request { get; private set; }
        public string ContentType { get; private set; }
        public long ContentLength { get; private set; }
        public string ContentEncoding { get; private set; }
        public string Content { get; private set; }
        public HttpStatusCode StatusCode { get; private set; }

        public bool IsSuccessful { get; private set; }

        public string StatusDescription { get; private set; }
        public byte[] RawBytes { get; private set; }
        public Uri ResponseUri { get; private set; }
        public string Server { get; private set; }

        public ResponseStatus ResponseStatus { get; private set; }
        public string ErrorMessage { get; private set; }
        public Exception ErrorException { get; private set; }
        public Version ProtocolVersion { get; private set; }
    }
}
