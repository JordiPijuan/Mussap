﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.ApiClient.Models
{
    public interface IRestApiResponse
    {
        string Content { get; }
        HttpStatusCode StatusCode { get; }

        bool IsSuccessful { get; }
    }
}
