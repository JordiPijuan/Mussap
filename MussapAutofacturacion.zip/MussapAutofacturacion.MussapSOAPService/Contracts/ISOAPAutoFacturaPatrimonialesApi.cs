﻿using SOAPAutoFacturaPatrimonialesService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.MussapSOAPService.Contracts
{
    public interface ISOAPAutoFacturaPatrimonialesApi
    {
        Task<WSA2AutoFacturaPatrimonialesPortTypeClient> GetInstanceAsync();
        Task<obtenerCodigosDePagoDisponiblesResponse> GetCodigosDePagoDisponiblesAsync(int numSiniestro, string nifTomador);
        Task<creaAutoFacturaResponse> CreaAutoFacturaAsync(WSInfoSiniestro infoSiniestro);
    }
}
