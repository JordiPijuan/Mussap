﻿using MussapAutofacturacion.MussapSOAPService.Contracts;
using SOAPAutoFacturaPatrimonialesService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.MussapSOAPService
{
    public class SOAPAutoFacturaPatrimonialesClient : ISOAPAutoFacturaPatrimonialesApi
    {
        public readonly string soapServiceUrl ;
        public readonly EndpointAddress endpointAddress;
        public readonly BasicHttpsBinding basicHttpsBinding;
        private readonly string soapUsername;
        private readonly string soapPassword;

        public SOAPAutoFacturaPatrimonialesClient(string serviceUrl, string userName, string password)
        {
            soapServiceUrl = serviceUrl;
            soapUsername = userName;
            soapPassword = password;
            endpointAddress = new EndpointAddress(soapServiceUrl);
            basicHttpsBinding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport);

            basicHttpsBinding.OpenTimeout = TimeSpan.MaxValue;
            basicHttpsBinding.CloseTimeout = TimeSpan.MaxValue;
            basicHttpsBinding.ReceiveTimeout = TimeSpan.MaxValue;
            basicHttpsBinding.SendTimeout = TimeSpan.MaxValue;

        }

        public async Task<WSA2AutoFacturaPatrimonialesPortTypeClient> GetInstanceAsync()
        {
            return await Task.Run(() => new WSA2AutoFacturaPatrimonialesPortTypeClient(basicHttpsBinding, endpointAddress));
        }

        public async Task<obtenerCodigosDePagoDisponiblesResponse> GetCodigosDePagoDisponiblesAsync(int numSiniestro, string nifTomador)
        {
            var client = await GetInstanceAsync();
            return await client.obtenerCodigosDePagoDisponiblesAsync(
                "obtenerCodigosDePagoDisponibles",
                soapUsername,
                soapPassword,
                numSiniestro,
                nifTomador);
        }

        public async Task<creaAutoFacturaResponse> CreaAutoFacturaAsync(WSInfoSiniestro infoSiniestro)
        {
            var client = await GetInstanceAsync();
            return await client.creaAutoFacturaAsync(
                "creaAutoFactura",
                soapUsername,
                soapPassword,
                infoSiniestro);
        }
    }
}
