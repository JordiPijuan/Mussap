﻿using MussapAutofacturacion.Application.Contracts;
using MussapAutofacturacion.Business.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Application
{
    public class ScheduledProcessesStore : IScheduledProcessesStore
    {
        private readonly IEnumerable<IScheduledProcess> _scheduledProcesses;
        private readonly IDictionary<string, ProcessDto> _processesTaskDictionary;

        public ScheduledProcessesStore(IScheduledProcessesProvider scheduledProcessesProvider)
        {
            _scheduledProcesses = scheduledProcessesProvider.GetProcesses();
            _processesTaskDictionary = new Dictionary<string, ProcessDto>();
        }

        public IEnumerable<IScheduledProcess> GetProcesses() => _scheduledProcesses;

        public IEnumerable<ProcessDto> GetProcessesDtos()
            => _scheduledProcesses
                .Select(GetProcessDto);

        public TProcess GetProcess<TProcess>()
            where TProcess : IScheduledProcess
        {
            var service = _scheduledProcesses
                               .OfType<TProcess>()
                               .SingleOrDefault();

            if (service == null)
                throw new ArgumentException($"The scheduled process of type: {typeof(TProcess)} is not included in the {nameof(ScheduledProcessesStore)}."); //ToDo Add Custom Exception

            return service;
        }

        public IScheduledProcess GetProcessByName(string processName)
        {
            var process = GetProcesses()
                .SingleOrDefault(p => p.GetType().Name.ToLower() == processName.ToLower());

            if (process is null) return null;

            return process;
        }

        public ProcessDto GetProcessDto(IScheduledProcess process)
        {
            if (process is null) return null;
            var processDto = new ProcessDto { Name = process.GetType().Name };

            if (_processesTaskDictionary.ContainsKey(processDto.Name))
            {
                processDto = _processesTaskDictionary[processDto.Name];
            }
            return processDto;
        }

        public ProcessDto GetProcessDtoByName(string processName)
        {
            var process = GetProcessByName(processName);
            var processDto = GetProcessDto(process);

            return processDto;
        }

        public void UpsertProcessDto(ProcessDto process)
        {
            if (_processesTaskDictionary.ContainsKey(process.Name))
            {
                _processesTaskDictionary[process.Name] = process;
            }
            else
            {
                _processesTaskDictionary.Add(process.Name, process);
            }
        }

        public bool ProcessIsRunning(IScheduledProcess process, out ProcessDto processDto)
        {
            processDto = new ProcessDto { Name = process.GetType().Name };

            if (_processesTaskDictionary.ContainsKey(processDto.Name))
            {
                processDto = _processesTaskDictionary[processDto.Name];
                return processDto.Task.Status == TaskStatus.Running;
            }

            return false;
        }
    }
}
