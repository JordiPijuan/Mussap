﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Application.Exceptions
{
    public class ApplicationStoreException : Exception
    {
        public ApplicationStoreException(string message)
            : base(message)
        {
        }
    }
}
