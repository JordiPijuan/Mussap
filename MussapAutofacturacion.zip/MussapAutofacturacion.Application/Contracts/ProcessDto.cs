﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Application.Contracts
{
    public class ProcessDto
    {
        public string Name { get; set; }
        public string TaskStatus { get => Task?.Status.ToString(); }
        public DateTime? LastInitProcessedDate { get; set; }

        [JsonIgnore]
        public Task Task { get; set; }
    }
}
