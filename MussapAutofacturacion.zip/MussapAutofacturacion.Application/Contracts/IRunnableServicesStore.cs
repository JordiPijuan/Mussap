﻿using MussapAutofacturacion.Business.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Application.Contracts
{
    public interface IRunnableServicesStore
    {
        IList<IRunnableService> GetServices();
        TService GetService<TService>() where TService : IRunnableService;
        IEnumerable<RunnableServiceDto> GetServicesDtos();
        RunnableServiceDto GetServiceDto(IRunnableService service);
        RunnableServiceDto GetServiceDtoByName(string serviceName);
        IRunnableService GetServiceByName(string serviceName);
        bool ServiceIsRunning(IRunnableService process, out RunnableServiceDto serviceDto);
        void UpsertSerciceDto(RunnableServiceDto serviceDto);
    }
}
