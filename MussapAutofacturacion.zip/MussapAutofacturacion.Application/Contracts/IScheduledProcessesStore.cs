﻿using MussapAutofacturacion.Business.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Application.Contracts
{
    public interface IScheduledProcessesStore
    {
        IEnumerable<IScheduledProcess> GetProcesses();
        IEnumerable<ProcessDto> GetProcessesDtos();

        TProcess GetProcess<TProcess>() where TProcess : IScheduledProcess;
        IScheduledProcess GetProcessByName(string processName);
        ProcessDto GetProcessDto(IScheduledProcess process);
        ProcessDto GetProcessDtoByName(string processName);
        void UpsertProcessDto(ProcessDto process);

        bool ProcessIsRunning(IScheduledProcess process, out ProcessDto processDto);
    }
}
