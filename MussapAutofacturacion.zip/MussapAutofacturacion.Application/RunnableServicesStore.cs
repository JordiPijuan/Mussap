﻿using MussapAutofacturacion.Application.Contracts;
using MussapAutofacturacion.Application.Exceptions;
using MussapAutofacturacion.Business.Contracts;
using MussapAutofacturacion.DI.Wrapper.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Application
{
    public class RunnableServicesStore : IRunnableServicesStore
    {
        private readonly IList<IRunnableService> _runnableServices;
        private readonly IDictionary<string, RunnableServiceDto> _processesTaskDictionary;

        public RunnableServicesStore(IDependenciesContainer container)
        {
            _processesTaskDictionary = new Dictionary<string, RunnableServiceDto>();

            var documentsService = container.GetInstance<IDocumentsService>();

            _runnableServices = new List<IRunnableService>
            {
                documentsService
            };
        }

        public IList<IRunnableService> GetServices()
            => _runnableServices;

        public TService GetService<TService>()
            where TService : IRunnableService
        {
            var service = _runnableServices
                               .OfType<TService>()
                               .SingleOrDefault();

            if (service == null)
                throw new ApplicationStoreException($"The service of type: {typeof(TService)} is not included in the {nameof(RunnableServicesStore)}.");

            return service;
        }

        public RunnableServiceDto GetServiceDto(IRunnableService service)
        {
            if (service is null) return null;
            var serviceDto = new RunnableServiceDto { Name = service.GetType().Name };

            if (_processesTaskDictionary.ContainsKey(serviceDto.Name))
            {
                serviceDto = _processesTaskDictionary[serviceDto.Name];
            }
            return serviceDto;
        }

        public IEnumerable<RunnableServiceDto> GetServicesDtos()
            => _runnableServices
                .Select(GetServiceDto);


        public RunnableServiceDto GetServiceDtoByName(string serviceName)
        {
            var service = GetServiceByName(serviceName);
            var serviceDto = GetServiceDto(service);

            return serviceDto;
        }

        public IRunnableService GetServiceByName(string serviceName)
        {
            var service = GetServices()
                .SingleOrDefault(p => p.GetType().Name.ToLower() == serviceName.ToLower());

            if (service is null) return null;

            return service;
        }

        public bool ServiceIsRunning(IRunnableService process, out RunnableServiceDto serviceDto)
        {
            serviceDto = new RunnableServiceDto { Name = process.GetType().Name };

            if (_processesTaskDictionary.ContainsKey(serviceDto.Name))
            {
                serviceDto = _processesTaskDictionary[serviceDto.Name];
                return serviceDto.Task.Status == TaskStatus.Running;
            }

            return false;
        }

        public void UpsertSerciceDto(RunnableServiceDto service)
        {
            if (_processesTaskDictionary.ContainsKey(service.Name))
            {
                _processesTaskDictionary[service.Name] = service;
            }
            else
            {
                _processesTaskDictionary.Add(service.Name, service);
            }
        }
    }
}
