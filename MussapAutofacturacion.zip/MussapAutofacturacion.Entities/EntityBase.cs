﻿namespace MussapAutofacturacion.Entities
{
    public abstract class EntityBase
    {
        //ToDo To Implement
    }
}
