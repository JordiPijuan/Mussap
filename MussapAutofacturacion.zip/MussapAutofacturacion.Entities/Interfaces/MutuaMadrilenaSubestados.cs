﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("INTERFACE_MUTUA_MADRILENA_SUBESTADOS")]
    public class MussapAutofacturacionSubestados : EntityBase
    {
        [Key]
        [Column("SUBESTADO_CD", Order = 1)]
        public string Substate { get; set; }

        [Key]
        [Column("PRIORIDAD_NU", Order = 2)]
        public int Priority { get; set; }

        [Column("DESCRIPTION_LB")]
        public string Description { get; set; }
    }
}