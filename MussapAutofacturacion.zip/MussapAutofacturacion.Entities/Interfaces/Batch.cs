﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("BATCH")]
    public class Batch : EntityBase
    {
        [Key]
        [Column("PROCESS_CD")]
        public string ProcessCode { get; set; }

        [Column("BATCH_NUMBER")]
        public int BatchNumber { get; set; }

        [Column("DESCRIP_LB")]
        public string Description { get; set; }

        [Column("SHIPPING_ID")]
        public int? ShippingId { get; set; }

        [Column("START_DT")]
        public DateTime? StartDate { get; set; }
    }
}
