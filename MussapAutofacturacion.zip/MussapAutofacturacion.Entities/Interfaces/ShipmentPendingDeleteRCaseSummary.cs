﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("SHIPMENT_PENDING_DELETED__R__CASE_SUMMARY", Schema = "online")]
    public class ShipmentPendingDeleteRCaseSummary : EntityBase
    {

        [Key]
        [Column("ID")]
        public int Id { get; set; }

        [Column("CASE_ID")]
        public long CaseId { get; set; }

        [Column("SUMMARY_NU")]
        public int SummaryNu { get; set; }

        [Column("SHIPMENT_ID")]
        public int ShipmentId { get; set; }

        [Column("CREATED_ID")]
        public int CreatedId { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreatedDate { get; set; }

        [Column("STORED_DS")]
        public string Stored { get; set; }

        [Column("TEXT_DS")]
        public string Text { get; set; }

        [Column("DELETED_ID")]
        public int DeletedId { get; set; }

        [Column("DELETE_DT")]
        public DateTime DeletedDate { get; set; }
    }
}
