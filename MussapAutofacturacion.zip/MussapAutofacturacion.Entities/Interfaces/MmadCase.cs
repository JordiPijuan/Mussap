﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("CASE", Schema = "mmad")]
    public class MmadCase : EntityBase
    {
        [Key]
        [Column("CASE_RECEIVED_ID")]
        public long CaseReceivedId { get; set; }

        [Column("CASE_ID")]
        public long CaseId { get; set; }

        [Column("TIPOREG_NU")]
        public int? RegisterType { get; set; }
    }
}
