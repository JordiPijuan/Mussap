﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("VIW_AdtCasestoSend", Schema = "mmad")]
    public class ViwAdtCasesToSend : EntityBase
    {
        public long CaseId { get; set; }

        [Column("SUMMARY_NU")]
        public int SummaryNu { get; set; }
    }
}
