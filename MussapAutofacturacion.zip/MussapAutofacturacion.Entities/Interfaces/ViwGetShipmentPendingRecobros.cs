﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("VIW_GetShipmentPendingRecobros", Schema = "mmad")]
    public class ViwGetShipmentPendingRecobros : EntityBase
    {
        public long CaseId { get; set; }
        public int SummaryNu { get; set; }
        public int ShipmentId { get; set; }
        public int SummaryTypeId { get; set; }
        public int? PersonNu { get; set; }
        public long? ReceivedCaseId { get; set; }
        public long? HomeCaseId { get; set; }
        public int? RecoverImport { get; set; }
    }
}
