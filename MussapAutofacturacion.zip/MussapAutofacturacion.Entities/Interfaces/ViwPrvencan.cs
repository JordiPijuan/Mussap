﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("VIW_PRVENCAN", Schema = "mmad")]
    public class ViwPrvencan : EntityBase
    {
        public long CaseId { get; set; }
        public int ServiceNu { get; set; }
        public int ServiceId { get; set; }
        public int? ExecutiveProviderId { get; set; }
    }
}
