﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("VIW_BillingCierreMmLogEnvios", Schema = "mmad")]
    public class ViwBillingCierreMmLogEnvios : EntityBase
    {
        public long CaseId { get; set; }
        public int ShipmentId { get; set; }
        public int? CaseTypeId { get; set; }
        public string ExternalCase { get; set; }
        public string PaymentType { get; set; }
    }
}
