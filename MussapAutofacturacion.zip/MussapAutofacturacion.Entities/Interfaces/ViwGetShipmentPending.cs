﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("VIW_GetShipmentPending", Schema = "mmad")]
    public class ViwGetShipmentPending : EntityBase
    {
        public long CaseId { get; set; }
        public int SummaryNu { get; set; }
        public int ShipmentId { get; set; }
        public int CreatedId { get; set; }
        public DateTime CreatedDate { get; set; }
        public int Priority { get; set; }
        public int SummaryTypeId { get; set; }
        public int? CaseTypeId { get; set; }
        public int? ContractId { get; set; }
        public int? ExecutiveProviderId { get; set; }
        public int? BenefitPartnerId { get; set; }
        public int? ServiceNu { get; set; }
        public int CaseStatusId { get; set; }
        public int? MonitoringNu { get; set; }
        public string ExternalCase { get; set; }
        public bool Reprocess { get; set; }
    }
}
