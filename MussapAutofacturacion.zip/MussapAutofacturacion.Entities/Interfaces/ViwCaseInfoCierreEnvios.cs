﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("VIW_CaseInfoCierreEnvios", Schema = "mmad")]
    public class ViwCaseInfoCierreEnvios : EntityBase
    {
        public long CaseId { get; set; }
        public int SummaryNu { get; set; }
        public DateTime? SendDate { get; set; }
        public int? CaseStatus { get; set; }
        public int SummaryTypeId { get; set; }
        public DateTime CreateDate { get; set; }
        public int ContractId { get; set; }
        public int? CaseTypeId { get; set; }
        public string ExternalCase { get; set; }
        public int StatusId { get; set; }
        public int? BatchNumber { get; set; }
        public string PaymentType { get; set; }
    }
}
