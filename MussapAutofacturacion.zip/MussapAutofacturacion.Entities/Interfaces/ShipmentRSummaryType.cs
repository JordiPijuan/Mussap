﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("online.SHIPMENT__R__SUMMARY_TYPE")]
    public class ShipmentRSummaryType : EntityBase
    {
        [Key]
        [Column("SUMMARY_TYPE_ID", Order = 1)]
        public long SummaryTypeId { get; set; }

        [Key]
        [Column("SHIPMENT_ID]", Order = 2)]
        public long ShipmentId { get; set; }

        [Column("EXECUTIVE_PROVIDER_ID")]
        public long? ExecutiveProviderId { get; set; }

        [Column("CONTRACT_ID")]
        public long? ContractId { get; set; }

        [Column("PARTNER_ID")]
        public long? PartnerId { get; set; }

        [Column("CONTRACT_GROUP_ID")]
        public long? ContractGroupId { get; set; }

        [Column("EXECUTIVE_PROVIDER_GROUP_ID")]
        public long? ExecutiveProviderGroupId { get; set; }

        [Column("ALL_BL")]
        public bool AllBl { get; set; }

        [Column("CREATED_ID")]
        public long CreatedId { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreateDate { get; set; }

        [Column("DELETED_ID")]
        public long DeletedId { get; set; }

        [Column("DELETE_DT")]
        public DateTime DeleteDate { get; set; }
    }
}
