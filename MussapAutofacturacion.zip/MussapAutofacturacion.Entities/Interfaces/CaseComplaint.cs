﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("INTERFACE_MUTUA_MADRILENIA_CASE_COMPLAINT")]
    public class CaseComplaint : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("COMPLAINT_NU", Order = 2)]
        public int ComplaintNu { get; set; }

        [Key]
        [Column("MM_COMPLAINT_NU", Order = 3)]
        public int MmComplaintNu { get; set; }
    }
}
