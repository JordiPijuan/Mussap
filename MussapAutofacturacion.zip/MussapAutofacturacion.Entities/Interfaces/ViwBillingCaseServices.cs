﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("VIW_BillingCaseServices", Schema = "mmad")]
    public class ViwBillingCaseServices : EntityBase
    {
        public long CaseId { get; set; }
        public int? ExecutiveProviderId { get; set; }
        public int ServiceId { get; set; }
        public int ServiceNu { get; set; }
        public int? NumLote { get; set; }
        public int StatusId { get; set; }
    }
}
