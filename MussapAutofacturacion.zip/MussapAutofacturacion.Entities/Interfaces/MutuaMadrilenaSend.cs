﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("INTERFACE_MUTUA_MADRILENA_SEND")]
    public class MussapAutofacturacionSend : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("SEND_ID", Order = 1)]
        public int SendId { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column("CASE_ID", Order = 2)]
        public int CaseId { get; set; }

        [Column("SEND_TYPE")]
        public string SendType { get; set; }

        [Column("SEND_MODO")]
        public string SendModo { get; set; }

        [Column("MODIF_TYPE")]
        public string ModifType { get; set; }

        [Column("SUMMARY_NU")]
        public int? SummaryNu { get; set; }

        [Column("BILL_ID")]
        public int? BillId { get; set; }

        [Column("SEND_DT")]
        public DateTime? SendDate { get; set; }

        [Column("SEND_VLDS")]
        public string SendJson { get; set; }

        [Column("RECEPTION_VLDS")]
        public string ReceptionJson { get; set; }

        [Column("RECEPTION_CD")]
        public string ReceptionCode { get; set; }

        [Column("RECEPTION_ERROR_CD")]
        public string ReceptionErrorCode { get; set; }

        [Column("RECEPTION_DS")]
        public string ReceptionDescription { get; set; }

        [Column("SHIPPING_ID")]
        public int? ShippingId { get; set; }

        [Column("MIR_ID")]
        public int? MirId { get; set; }

        [Column("CAUSE_PARTNER_ID")]
        public int? CausePartnerId { get; set; }

        [Column("SUBESTADO_CD")]
        public string SubstateCode { get; set; }

        [Column("PRIORIDAD_NU")]
        public decimal? Priority { get; set; }

        [Column("CAUSANTES_NU")]
        public int? CausersNumber { get; set; }

        [Column("SEND_EMAIL_DT")]
        public DateTime? SendMailDate { get; set; }
    }

    [Table("MM_SEND", Schema = "mmad")]
    public class MMSend : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(Order = 1)]
        public long SendId { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(Order = 2)]
        public long CaseId { get; set; }

        public string SendType { get; set; }
        public string SendModo { get; set; }
        public string ModifType { get; set; }
        public int? Summary { get; set; }
        public int? BillId { get; set; }
        public DateTime? SendDate { get; set; }
        public string SendJson { get; set; }
        public string SendJsonPath { get; set; }
        public string ReceptionJson { get; set; }
        public string ReceptionJsonPath { get; set; }
        public string ReceptionCode { get; set; }
        public string ReceptionErrorCode { get; set; }
        public string ReceptionDescription { get; set; }
        public int? SinisterType { get; set; }
        public int? CauseCode { get; set; }
        public string Substate { get; set; }
        public int? Priority { get; set; }
        public DateTime? EmailSendedDate { get; set; }
        public string OperationId { get; set; }
        public int HttpStatusCode { get; set; }
    }

    [Table("MM_SEND_RECOBRO", Schema = "mmad")]
    public class MMSendRecobro : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(Order = 1)]
        public long SendId { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(Order = 2)]
        public long CaseId { get; set; }

        public string SendType { get; set; }
        public string SendModo { get; set; }
        public string ModifType { get; set; }
        public int? Summary { get; set; }
        public int? BillId { get; set; }
        public DateTime? SendDate { get; set; }
        public string SendJson { get; set; }
        public string SendJsonPath { get; set; }
        public string ReceptionJson { get; set; }
        public string ReceptionJsonPath { get; set; }
        public string ReceptionCode { get; set; }
        public string ReceptionErrorCode { get; set; }
        public string ReceptionDescription { get; set; }
        public int? SinisterType { get; set; }
        public int? CauseCode { get; set; }
        public string Substate { get; set; }
        public int? Priority { get; set; }
        public DateTime? EmailSendedDate { get; set; }
        public string OperationId { get; set; }
        public int HttpStatusCode { get; set; }
        public int SummaryTypeId { get; set; }
    }

    [Table("MM_SEND_ADT_DOCUMENT", Schema = "mmad")]
    public class MMSendAdtDocument : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(Order = 1)]
        public long SendId { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(Order = 2)]
        public long CaseId { get; set; }

        public int? Summary { get; set; }
        public DateTime? SendDate { get; set; }
        public string SendJson { get; set; }
        public string SendJsonPath { get; set; }
        public string ReceptionJson { get; set; }
        public string ReceptionJsonPath { get; set; }
        public string ReceptionCode { get; set; }
        public string ReceptionErrorCode { get; set; }
        public string ReceptionDescription { get; set; }
        public DateTime? EmailSendedDate { get; set; }
        public string OperationId { get; set; }
        public int HttpStatusCode { get; set; }
    }
}