﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("CASE_TO_REPROCESS", Schema = "mmad")]
    public class MmadCaseToReprocess : EntityBase
    {
        [Key]
        [Column("CASE_TO_REPROCESS_ID")]
        public long CaseToReprocessId { get; set; }

        [Column("CASE_ID")]
        public long CaseId { get; set; }

        [Column("SHIPMENT_ID")]
        public long ShipmentId { get; set; }
    }
}
