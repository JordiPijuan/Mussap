﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("SHIPMENT_SENDED__R__CASE_SUMMARY", Schema = "online")]
    public class ShipmentSendedRCaseSummary : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("SUMMARY_NU", Order = 2)]
        public int SummaryNu { get; set; }

        [Key]
        [Column("SHIPMENT_ID", Order = 3)]
        public int ShipmentId { get; set; }

        [Column("CREATED_ID")]
        public int CreatedId { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreatedDate { get; set; }

        [Column("SEND_ID")]
        public int? SendId { get; set; }

        [Column("SEND_DT")]
        public DateTime? SendDate { get; set; }
    }
}
