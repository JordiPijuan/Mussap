﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("CIERRE_MM_LOG_ENVIO")]
    public class CierreMmLogEnvio : EntityBase
    {
        [Key]
        [Column("CIERRE_MM_LOG_ID")]
        public int Id { get; set; }

        [Column("NUM_LOTE")]
        public int? BatchNumber { get; set; }
        
        [Column("TIPO_PAGO")]
        public string PaymentType { get; set; }

        [Column("CASE_ID")]
        public long CaseId { get; set; }

        [Column("NUMERO_SERVICIO")]
        public string ServiceNumber { get; set; }

        [Column("importe01")]
        public string Amount01 { get; set; }
    }
}
