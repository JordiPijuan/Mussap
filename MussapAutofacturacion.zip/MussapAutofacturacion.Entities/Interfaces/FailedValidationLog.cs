﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Interfaces
{
    [Table("FAILED_VALIDATION_LOG", Schema = "mmad")]
    public class FailedValidationLog : ValidationLogEntityBase
    {

    }

    [Table("FAILED_VALIDATION_LOG_RECOBRO", Schema = "mmad")]
    public class FailedValidationLogRecobro : ValidationLogEntityBase
    {

    }

    public abstract class ValidationLogEntityBase : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("SUMMARY_NU", Order = 2)]
        public int SummaryNu { get; set; }

        [Column("VALIDATION_VLDS")]
        public string ValidationErrorMessages { get; set; }

        [Column("MODIF_TYPE")]
        public string ModifType { get; set; }
    }
}
