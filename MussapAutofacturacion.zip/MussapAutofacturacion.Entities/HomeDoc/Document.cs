﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.HomeDoc
{
    [Table("DOCUMENT", Schema = "dbo")]
    public class Document : EntityBase
    {
        [Key]
        [Column("DOCUMENT_ID", Order = 1)]
        public long Id { get; set; }

        [Key]
        [Column("VERSION_NU", Order = 2)]
        public int Version { get; set; }

        [Column("TITLE_LB")]
        public string Title { get; set; }

        [Column("CONTENT_TYPE_ID")]
        public int? ContentTypeId { get; set; }

        [Column("DOCUMENT_IMG")]
        public byte[] File { get; set; }

        [Column("CREATED_ID")]
        public long CreateId { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreateDate { get; set; }

        [Column("DELETED_ID")]
        public int? DeleteId { get; set; }

        [Column("DELETE_DT")]
        public DateTime? DeleteDate { get; set; }
    }
}
