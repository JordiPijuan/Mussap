﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("CASE_SERVICE")]
    public class CaseService : EntityBase
    {
        [Key]
        [Column("CASE_ID")]
        public long CaseId { get; set; }

        [Column("SERVICE_NU")]
        public int ServiceNu { get; set; }

        [Column("SERVICE_ID")]
        public int ServiceId { get; set; }

        [Column("EXECUTIVE_PROVIDER_ID")]
        public int ExecutiveProviderId { get; set; }

        [Column("SERVICE_LDS")]
        public string ServiceDescription { get; set; }
    }
}
