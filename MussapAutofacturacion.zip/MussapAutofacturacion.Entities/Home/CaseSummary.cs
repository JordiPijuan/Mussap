﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("CASE_SUMMARY")]
    public class CaseSummary : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public int Sinister { get; set; }

        public long CaseId { get { return Convert.ToInt64(Sinister); } }

        [Key]
        [Column("SUMMARY_NU", Order = 2)]
        public int SummaryNu { get; set; }

        [Column("SERVICE_NU")]
        public int? ServiceNu { get; set; }

        [Column("SUMMARY_TYPE_ID")]
        public int SummaryTypeId { get; set; }

        [Column("CONTRACT_ID")]
        public int? ContractId { get; set; }

        [Column("EXECUTIVE_PROVIDER_ID")]
        public int? ExecutiveProviderId { get; set; }

        [Column("SUMMARY_LDS")]
        public string SummaryLds { get; set; }

        [Column("DESCRIPTION_LDS")]
        public string Description { get; set; }

        [Column("START_DT")]
        public DateTime? StartDate { get; set; }

        [Column("END_DT")]
        public DateTime? EndDate { get; set; }

        [Column("SERVICE_ID")]
        public int? ServiceId { get; set; }

        [Column("TRANSFER_BL")]
        public bool? Transfer { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreateDate { get; set; }

        [Column("CREATED_ID")]
        public int CreatedId { get; set; }

        [Column("SURVEY_NU")]
        public int? SurveyNu { get; set; }

        [Column("RECEPTION_NU")]
        public int? ReceptionNu { get; set; }

        [Column("SENDING_NU")]
        public int? SendingNu { get; set; }

        [Column("CASE_STATUS_NU")]
        public int? CaseStatusNu { get; set; }

        [Column("INDEMNITY_NU")]
        public int? IndemnityNu { get; set; }

        [Column("PERSON_NU")]
        public int? PersonNu { get; set; }

        [Column("BENEFIT_ID")]
        public int? BenefitId { get; set; }

        [Column("BENEFIT_PARTNER_ID")]
        public int? BenefitPartnerId { get; set; }

        [Column("MONITORING_NU")]
        public int? MonitoringNu { get; set; }

        [Column("COMPLAINT_NU")]
        public int? ComplaintNu { get; set; }

        [Column("APPOINTMENT_NU")]
        public int? AppointmentNu { get; set; }

        [Column("SEND_DT")]
        public DateTime? SendDate { get; set; }

        [Column("DOCUMENT_ID")]
        public int? DocumentId { get; set; }

        [Column("HOME_BILL_ID")]
        public int? HomeBillId { get; set; }

        [Column("STANDBY_NU")]
        public int? StandbyNu { get; set; }

        [Column("SEND_NU")]
        public int? SendNu { get; set; }

        [Column("BUDGET_ID")]
        public long? BudgetId { get; set; }

        [Column("PROFESSION_NU")]
        public int? ProfessionNu { get; set; }

        [Column("OPINION_POLL_NU")]
        public int? OpinionPollNu { get; set; }

        [Column("POLL_ID")]
        public int? PollId { get; set; }
    }
}
