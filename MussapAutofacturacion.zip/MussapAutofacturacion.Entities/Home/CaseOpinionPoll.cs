﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("CASE_OPINION_POLL")]
    public class CaseOpinionPoll : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("OPINION_POLL_NU", Order = 2)]
        public int OpinionPollNu { get; set; }

        [Column("POLL_ID")]
        public int PollId { get; set; }

        [Column("OBSERVATION_DS")]
        public string Observations { get; set; }

        [Column("STATUS_ID")]
        public int StatusId { get; set; }

        [Column("MONITORING_TYPE_ID")]
        public int? MonitoringTypeId { get; set; }

        [Column("ACTIVATE_DT")]
        public DateTime? ActivateDate { get; set; }

        [Column("POSTPONE_DT")]
        public DateTime? PostponeDate { get; set; }

        [Column("END_DT")]
        public DateTime? EndDate { get; set; }

        [Column("END_ID")]
        public int? EndId { get; set; }

        [Column("NOCONTACT_NU")]
        public int? NoContactNu { get; set; }

        [Column("POSTPONE_NU")]
        public int? PostponeNu { get; set; }

        [Column("PERSON_NU")]
        public int? PersonNu { get; set; }

        [Column("VALUATION_DC")]
        public decimal? Valuation { get; set; }

        [Column("COMMUNICATION_NU")]
        public int? CommunicationNu { get; set; }

        [Column("CREATED_ID")]
        public int CreatedId { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreateDate { get; set; }

        [Column("DELETED_ID")]
        public int? DeletedId { get; set; }

        [Column("DELETE_DT")]
        public DateTime? DeleteDate { get; set; }
    }
}