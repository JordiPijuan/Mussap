﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("dbo.CASE_STATUS_DATE")]
    public class CaseStatusDate : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("CASE_STATUS_NU", Order = 2)]
        public int CaseStatusNu { get; set; }

        [Column("STATUS_ID")]
        public int StatusId { get; set; }

        [Column("STATUS_DT")]
        public DateTime StatusDate { get; set; }

        [Column("REASON_ID")]
        public int? ReasonId { get; set; }

        [Column("REASON_CONTRACT_ID")]
        public int? ReasonContractId { get; set; }

        [Column("REASON_DS")]
        public string ReasonDescription { get; set; }

        [Column("CONTRACT_LETTER_ID")]
        public int? ContractLetterId { get; set; }
        
        [Column("CREATED_ID")]
        public int CreatedId { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreateDate { get; set; }

        [Column("UNDERSTAND_REASON_ID")]
        public int? UnderstandReasonId { get; set; }

        [Column("ACCORDING_REASON_BL")]
        public bool AccordingReason { get; set; }

        [Column("STATUS_ORIGIN_ID")]
        public int? StatusOriginId { get; set; }        
    }
}
