﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("CASE_OPINION_POLL_ANSWER")]
    public class CaseOpinionPollAnswer : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("OPINION_POLL_NU", Order = 2)]
        public int OpinionPollNu { get; set; }

        [Key]
        [Column("QUESTION_ID", Order = 3)]
        public int QuestionId { get; set; }

        [Column("ANSWER_ID")]
        public int AnswerIdInt { get; set; }
        public long AnswerId { get => AnswerIdInt; }

        [Column("CREATED_ID")]
        public int CreatedId { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreateDate { get; set; }

        [Column("DELETED_ID")]
        public int? DeletedId { get; set; }

        [Column("DELETE_DT")]
        public DateTime? DeleteDate { get; set; }

        [Column("ANSWER_LDS")]
        public string Answer { get; set; }
    }
}
