﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("CASE_SERVICE_MONITORING")]
    public class CaseServiceMonitoring : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("SERVICE_NU", Order = 2)]
        public int ServiceNu { get; set; }

        [Key]
        [Column("MONITORING_NU", Order = 3)]
        public int MonitoringNu { get; set; }

        [Column("MONITORING_TYPE_ID")]
        public int? MonitoringTypeId { get; set; }

        [Column("TITLE_LB")]
        public string Title { get; set; }

        [Column("DESCRIPTION_DS")]
        public string Description { get; set; }

        [Column("END_BL")]
        public bool EndBl { get; set; }

        [Column("ACTIVATE_DT")]
        public DateTime? ActivateDate { get; set; }

        [Column("END_ID")]
        public int? EndId { get; set; }

        [Column("END_DT")]
        public DateTime? EndDate { get; set; }

        [Column("END_DS")]
        public string EndDescription { get; set; }

        [Column("OBSERVATION_DS")]
        public string Observation { get; set; }

        [Column("CREATED_ID")]
        public int CreatedId { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreateDate { get; set; }

        [Column("AMOUNT_DC")]
        public decimal? Amount { get; set; }
    }
}
