﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("CASE_COMPLAINT")]
    public class CaseComplaint : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("COMPLAINT_NU", Order = 2)]
        public int ComplaintNu { get; set; }

        [Column("INCIDENT_DT")]
        public DateTime? IncidentDate { get; set; }

        [Column("COMPLAINT_ORIGIN_ID")]
        public int ComplaintOriginId { get; set; }
    }
}
