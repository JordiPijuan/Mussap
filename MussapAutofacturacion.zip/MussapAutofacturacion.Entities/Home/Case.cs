﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("CASE")]
    public class Case : EntityBase
    {
        [Key]
        [Column("CASE_ID")]
        public long CaseId { get; set; }

        [Column("CONTRACT_ID")]
        public int ContractId { get; set; }

        [Column("CAUSE_ID")]
        public int? CauseId { get; set; }

        [Column("STATUS_ID")]
        public int StatusId { get; set; }

        [Column("REASON_ID")]
        public int? ReasonId { get; set; }

        [Column("REASON_DS")]
        public string ReasonDescription { get; set; }

        [Column("LOCK_USER_ID")]
        public int? LockUserId { get; set; }

        [Column("ADDRESS_ID")]
        public long? AddressId { get; set; }

        [Column("EXTERNAL_CASE_TX")]
        public string ExternalCase { get; set; }

        [Column("SINISTER_DT")]
        public DateTime? SinisterDate { get; set; }

        [Column("SINISTER_DESCRIPTION_DS")]
        public string SinisterDescription { get; set; }

        [Column("SINISTER_LOCATION_LDS")]
        public string SinisterLocation { get; set; }

        [Column("CASE_TYPE_ID")]
        public int? CaseTypeId { get; set; }

        [Column("ORIGIN_ID")]
        public int? OriginId { get; set; }

        [Column("URGENT_BL")]
        public bool? IsUrgent { get; set; }

        [Column("SMS_ACTIVE_BL")]
        public bool? IsSmsActive { get; set; }

        [Column("POLICY_TX")]
        public string Policy { get; set; }

        [Column("VIP_ID")]
        public long? VipId { get; set; }

        [Column("SINISTER_TYPE_ID")]
        public int? SinisterTypeId { get; set; }

        [Column("CREATED_ID")]
        public int CreatedId { get; set; }

        [Column("CREATE_DT")]
        public DateTime CreateDate { get; set; }

        [Column("DELETED_ID")]
        public int? DeletedId { get; set; }

        [Column("DELETE_DT")]
        public DateTime? DeleteDate { get; set; }
    }
}
