﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("CASE_MONITORING")]
    public class CaseMonitoring : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("MONITORING_NU", Order = 2)]
        public int MonitoringNu { get; set; }

        [Column("MONITORING_TYPE_ID")]
        public int MonitoringTypeId { get; set; }
    }
}
