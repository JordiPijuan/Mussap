﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MussapAutofacturacion.Entities.Home
{
    [Table("CASE_SERVICE_INDEMNITY")]
    public class CaseServiceIndemnity : EntityBase
    {
        [Key]
        [Column("CASE_ID", Order = 1)]
        public long CaseId { get; set; }

        [Key]
        [Column("SERVICE_NU", Order = 2)]
        public int ServiceNu { get; set; }

        [Key]
        [Column("INDEMNITY_NU", Order = 3)]
        public int IndemnityNu { get; set; }
        
        [Column("INDEMNITY_TYPE_ID")]
        public int? IndemnityTypeId { get; set; }

        [Column("AMOUNT_DC")]
        public int? Amount { get; set; }

        [Column("END_DT")]
        public DateTime? EndDate { get; set; }
    }
}