﻿using Microsoft.EntityFrameworkCore;

namespace MussapAutofacturacion.Infrastructure.NetStandard.Contexts
{
    public class HomeEsContext : DbContext
    {
        public HomeEsContext(DbContextOptions<HomeEsContext> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Query<ExpertAssignmentGetExpertCompanyResult>();
            //modelBuilder.Query<ExpertAddRejectResult>();
        }
    }
}
