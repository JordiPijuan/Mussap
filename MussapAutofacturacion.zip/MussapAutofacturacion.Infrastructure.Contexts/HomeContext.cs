﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MussapAutofacturacion.Common;
using MussapAutofacturacion.Entities.Home;
using MussapAutofacturacion.Logger;

namespace MussapAutofacturacion.Infrastructure.NetStandard.Contexts
{
    public class HomeContext : DbContext
    {
        private readonly ILoggerFactory _loggerFactory;

        public HomeContext(DbContextOptions<HomeContext> options)
            : base(options)
        {
            var logger = new EfCoreLogger();

            if (ApiManagement.EfLoggerProviderEnabled) _loggerFactory = 
                    new LoggerFactory(new[] { new EfCoreLoggerProvider(logger) });
            
        }

        public DbSet<CaseSummary> CaseSummaries { get; set; }
        public DbSet<Case> Cases { get; set; }
        public DbSet<CaseOpinionPoll> CaseOpinionPolls { get; set; }
        public DbSet<CaseOpinionPollAnswer> CaseOpinionPollAnswers{ get; set; }
        public DbSet<CaseServiceMonitoring> CaseServiceMonitorings { get; set; }
        public DbSet<CaseMonitoring> CaseMonitorings { get; set; }
        public DbSet<CaseServiceIndemnity> CaseServiceIndemnities { get; set; }
        public DbSet<CaseComplaint> CaseComplaints { get; set; }
        public DbSet<CaseService> CaseServices { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            //#warning "Remove sensistive data logging"
            //optionsBuilder.EnableSensitiveDataLogging(); //ToDo Remove Sensitive Data Logging!!

            if(ApiManagement.EfLoggerProviderEnabled)            
                optionsBuilder.UseLoggerFactory(_loggerFactory);
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CaseSummary>()
                .HasKey(c => new { c.Sinister, c.SummaryNu });

            modelBuilder.Entity<Case>()
                .HasKey(c => c.CaseId );

            modelBuilder.Entity<CaseOpinionPoll>()
                .HasKey(c => new { c.CaseId, c.OpinionPollNu });

            modelBuilder.Entity<CaseOpinionPollAnswer>()
                .HasKey(c => new { c.CaseId, c.OpinionPollNu, c.QuestionId });

            modelBuilder.Entity<CaseServiceMonitoring>()
                .HasKey(c => new { c.CaseId, c.ServiceNu, c.MonitoringNu });

            modelBuilder.Entity<CaseMonitoring>()
                .HasKey(c => new { c.CaseId, c.MonitoringNu });

            modelBuilder.Entity<CaseServiceIndemnity>()
                .HasKey(c => new { c.CaseId, c.ServiceNu, c.IndemnityNu });

            modelBuilder.Entity<CaseComplaint>()
                .HasKey(c => new { c.CaseId, c.ComplaintNu });

            modelBuilder.Entity<CaseService>()
                .HasKey(c => c.CaseId);

            //modelBuilder.Query<CaseGenericMonitoringResult>();
            //modelBuilder.Query<CaseServiceSurveyAutomaticAssignmentQueueResult>();
            //modelBuilder.Query<SpuCaseExternalCaseResult>();            
        }
    }    
}
