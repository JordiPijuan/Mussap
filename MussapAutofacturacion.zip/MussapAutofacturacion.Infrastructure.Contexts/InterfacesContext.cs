﻿using Microsoft.EntityFrameworkCore;
using MussapAutofacturacion.Entities.Interfaces;
using MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures;
using MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures.MussapAutofacturaStoredProcedure;

namespace MussapAutofacturacion.Infrastructure.NetStandard.Contexts
{
    public class InterfacesContext : DbContext
    {
        public InterfacesContext(DbContextOptions<InterfacesContext> options)
            : base(options)
        { }

        public DbSet<ShipmentPendingRCaseSummary> ShipmentPendingRCaseSummaries { get; set; }
        public DbSet<ShipmentSendedRCaseSummary> ShipmentSendedRCaseSummaries { get; set; }
        //public DbSet<FailedValidationLog> FailedValidationLogs { get; set; }
        //public DbSet<FailedValidationLogRecobro> FailedValidationLogRecobros { get; set; }
        //public DbSet<MussapAutofacturacionSend> MussapAutofacturacionSends { get; set; }
      
        public DbSet<SpMussappAutofacturacionResult> SpMussappAutofacturacionResults { get; set; }
        public DbSet<SpMussappRelatedFilesResult> SpMussappRelatedFilesResults { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SpMussappRelatedFilesResult>().HasNoKey();
            modelBuilder.Entity<SpMussappAutofacturacionResult>().HasNoKey();
            modelBuilder
                .Entity<ShipmentPendingRCaseSummary>()
                .HasKey(c => new { c.CaseId, c.SummaryNu, c.ShipmentId });

            modelBuilder
                .Entity<ShipmentSendedRCaseSummary>()
                .HasKey(c => new { c.CaseId, c.SummaryNu, c.ShipmentId });

           
            base.OnModelCreating(modelBuilder);
        }
    }
}
