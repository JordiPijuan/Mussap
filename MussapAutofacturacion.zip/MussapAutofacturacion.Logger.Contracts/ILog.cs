﻿using System;
using System.Runtime.CompilerServices;

namespace MussapAutofacturacion.Logger.Contracts
{
    public interface ILog<T> where T : class
    {
        void Debug(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0);
        void Error(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0);
        void Error(string message, Exception exception, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0);
        void Fatal(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0);
        void Fatal(string message, Exception exception, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0);
        void Info(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0);
        void Warning(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0);
        void Warning(string message, Exception exception, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0);
    }
}
