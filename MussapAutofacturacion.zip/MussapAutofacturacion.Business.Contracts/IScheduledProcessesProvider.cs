﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Business.Contracts
{
    public interface IScheduledProcessesProvider
    {
        IEnumerable<IScheduledProcess> GetProcesses();
    }
}
