﻿using System;
using AutoMapper;
using MussapAutofacturacion.Common;
using MussapAutofacturacion.Common.Enums;
using MussapAutofacturacion.Entities.Interfaces;
using MussapAutofacturacion.Infrastructure.Contracts.Dtos;
using MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures.MussapAutofacturaStoredProcedure;
using SOAPAutoFacturaPatrimonialesService;

namespace MussapAutofacturacion.Business.Mappings
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap< SpMussappRelatedFilesResult, WSDocumento > ()
            .ForMember(dest => dest.nombre, opts => opts.MapFrom(src => src.Nombre))
               .ForMember(dest => dest.datos,
                  opts => opts.MapFrom((src, dest) =>
                  {
                      if (src.Datos != null )
                      {
                          return  BitConverter.ToString(src.Datos).Replace("-", string.Empty);
                           
                      }
                      return null;
                  }))
            .ReverseMap();

            CreateMap<SpMussappAutofacturacionResult, PendingSendedDto>()
                .ForMember(dest => dest.CaseId, opts => opts.MapFrom(src => src.Case_Id))
                .ForMember(dest => dest.ShipmentId, opts => opts.MapFrom(src => src.Shipment_Id))
                .ForMember(dest => dest.SummaryNu, opts => opts.MapFrom(src => src.Summary_Nu))
                .ReverseMap();

            CreateMap<WSInfoSiniestro, SpMussappAutofacturacionResult>()
                       .ForMember(dest => dest.AsistenciaRechazada,
                opts => opts.MapFrom(src => Convert.ToInt32(src.asistenciaRechazada)))

                        .ForMember(dest => dest.ConceptoPago,
                opts => opts.MapFrom(src => Convert.ToString( src.conceptoPago)))

                         .ForMember(dest => dest.EsInformeDeValoracionDeDanyos,
                opts => opts.MapFrom(src => Convert.ToInt32(src.esInformeDeValoracionDeDanyos)))

                         .ForMember(dest => dest.HaIntervenidoElPerito,
                opts => opts.MapFrom(src => Convert.ToInt32(src.haIntervenidoElPerito)))

                            .ForMember(dest => dest.ImporteDesplazamientos,
                opts => opts.MapFrom(src => Convert.ToDecimal(src.importeDesplazamientos)))

                            .ForMember(dest => dest.ImporteGestionExpediente,
                opts => opts.MapFrom(src => Convert.ToDecimal(src.importeGestionExpediente)))

                            .ForMember(dest => dest.ImporteHonorariosInformes,
                opts => opts.MapFrom(src => Convert.ToDecimal(src.importeHonorariosInformes)))

                           .ForMember(dest => dest.ImporteManoDeObra,
                opts => opts.MapFrom(src => Convert.ToDecimal(src.importeManoDeObra)))

                          .ForMember(dest => dest.ImporteMateriales,
                opts => opts.MapFrom(src => Convert.ToDecimal(src.importeMateriales)))

                          .ForMember(dest => dest.NifTomador,
                opts => opts.MapFrom(src => src.nifTomador))
                          .ForMember(dest => dest.NumeroFactura,
                 opts => opts.MapFrom(src => src.numeroFactura))
                          .ForMember(dest => dest.NumeroSiniestro,
                 opts => opts.MapFrom(src => Convert.ToString(src.numeroSiniestro)))

                              .ForMember(dest => dest.SiniestroFinalizado,
                 opts => opts.MapFrom(src => Convert.ToInt32(src.siniestroFinalizado)))

                            .ForMember(dest => dest.SiniestroNoCubierto,
                 opts => opts.MapFrom(src => Convert.ToInt32(src.siniestroFinalizado)))

                              .ForMember(dest => dest.SoloGestionesAsistencia,
                 opts => opts.MapFrom(src => Convert.ToInt32(src.soloGestionesAsistencia)))

                               .ForMember(dest => dest.DocFacturaDatos,
                 opts => opts.Ignore())
                               .ForMember(dest => dest.DocFacturaNombre,
                 opts => opts.Ignore())
                                .ForMember(dest => dest.DocFiniquitoConformidadClienteNombre,
                 opts => opts.Ignore())
                                .ForMember(dest => dest.DocFiniquitoConformidadClienteDatos,
                 opts => opts.Ignore())
                ;

            CreateMap<SpMussappAutofacturacionResult, WSInfoSiniestro>()
                         .ForMember(dest => dest.asistenciaRechazada,
                  opts => opts.MapFrom(src => Convert.ToBoolean(src.AsistenciaRechazada)))
                         .ForMember(dest => dest.asistenciaRechazadaSpecified,
                   opts => opts.MapFrom(src => true))
                          .ForMember(dest => dest.conceptoPago,
                  opts => opts.MapFrom(src =>  Convert.ToInt32(src.ConceptoPago)))
                          .ForMember(dest => dest.conceptoPagoSpecified,
                 opts => opts.MapFrom(src => true))
                           .ForMember(dest => dest.esInformeDeValoracionDeDanyos,
                  opts => opts.MapFrom(src => Convert.ToBoolean(src.EsInformeDeValoracionDeDanyos)))
                           .ForMember(dest => dest.esInformeDeValoracionDeDanyosSpecified,
                   opts => opts.MapFrom(src => true))
                           .ForMember(dest => dest.haIntervenidoElPerito,
                  opts => opts.MapFrom(src => Convert.ToBoolean(src.HaIntervenidoElPerito)))
                           .ForMember(dest => dest.haIntervenidoElPeritoSpecified,
                    opts => opts.MapFrom(src => true))
                              .ForMember(dest => dest.importeDesplazamientos,
                  opts => opts.MapFrom(src => Convert.ToDouble(src.ImporteDesplazamientos)))
                               .ForMember(dest => dest.importeDesplazamientosSpecified,
                   opts => opts.MapFrom(src => true))
                              .ForMember(dest => dest.importeGestionExpediente,
                  opts => opts.MapFrom(src => Convert.ToDouble(src.ImporteGestionExpediente)))
                              .ForMember(dest => dest.importeGestionExpedienteSpecified,
                   opts => opts.MapFrom(src => true))
                              .ForMember(dest => dest.importeHonorariosInformes,
                  opts => opts.MapFrom(src => Convert.ToDouble(src.ImporteHonorariosInformes)))
                             .ForMember(dest => dest.importeHonorariosInformesSpecified,
                   opts => opts.MapFrom(src => true))
                             .ForMember(dest => dest.importeManoDeObra,
                  opts => opts.MapFrom(src => Convert.ToDouble(src.ImporteManoDeObra)))
                            .ForMember(dest => dest.importeManoDeObraSpecified,
                   opts => opts.MapFrom(src => true))
                            .ForMember(dest => dest.importeMateriales,
                  opts => opts.MapFrom(src => Convert.ToDouble(src.ImporteMateriales)))
                            .ForMember(dest => dest.importeMaterialesSpecified,
                opts => opts.MapFrom(src => true))
                            .ForMember(dest => dest.nifTomador,
                  opts => opts.MapFrom(src => src.NifTomador))
                            .ForMember(dest => dest.numeroFactura,
                   opts => opts.MapFrom(src => src.NumeroFactura))
                            .ForMember(dest => dest.numeroSiniestro,
                   opts => opts.MapFrom(src => Convert.ToInt32(src.NumeroSiniestro)))
                            .ForMember(dest => dest.numeroSiniestroSpecified,
                    opts => opts.MapFrom(src => true))
                                .ForMember(dest => dest.siniestroFinalizado,
                   opts => opts.MapFrom(src => Convert.ToBoolean(src.SiniestroFinalizado)))
                             .ForMember(dest => dest.siniestroFinalizadoSpecified,
                   opts => opts.MapFrom(src => true))
                              .ForMember(dest => dest.siniestroNoCubierto,
                   opts => opts.MapFrom(src => Convert.ToBoolean(src.SiniestroFinalizado)))
                               .ForMember(dest => dest.siniestroNoCubiertoSpecified,
                   opts => opts.MapFrom(src => true))
                                .ForMember(dest => dest.soloGestionesAsistencia,
                   opts => opts.MapFrom(src => Convert.ToBoolean(src.SoloGestionesAsistencia)))
                                 .ForMember(dest => dest.soloGestionesAsistenciaSpecified,
                   opts => opts.MapFrom(src => true))
                                 .ForMember(dest => dest.docFactura,
                  opts => opts.MapFrom((src,dest) =>
                  {
                      if (src.DocFacturaDatos != null)
                      {
                         return new WSDocumento()
                          {
                              datos =  BitConverter.ToString(src.DocFacturaDatos).Replace("-", string.Empty),
                              nombre = src.DocFacturaNombre
                          };
                      }
                      return null;
                  }))
                        .ForMember(dest => dest.docFiniquitoConformidadCliente,
                  opts => opts.MapFrom((src, dest) =>
                  {
                      if (src.DocFiniquitoConformidadClienteDatos != null)
                      {
                          return new WSDocumento()
                          {
                              datos =  BitConverter.ToString(src.DocFiniquitoConformidadClienteDatos).Replace("-", string.Empty),
                              nombre = src.DocFiniquitoConformidadClienteNombre
                          };
                      }
                      return null;
                  }))
                                  .ForMember(dest => dest.docsFotografiasDanyos,
                  opts => opts.MapFrom((src, dest) =>
                  {
                      if (src.DocFiniquitoConformidadClienteDatos != null)
                      {
                          return new WSDocumento[]
                          {
                             new WSDocumento{
                              datos =  BitConverter.ToString( src.DocFiniquitoConformidadClienteDatos).Replace("-", string.Empty),
                              nombre = src.DocFiniquitoConformidadClienteNombre
                             }
                          };
                      }
                      return null;
                  }))
                  ;
        }

        private (int sendType, string sendModo, string modifType) ConvertSummaryType(long summaryTypeId)
        {
            var summaryType = (SummaryTypes) summaryTypeId;

            return SummaryTypeConvert.GetSummaryTypeData(summaryType);
        }
    }
}
