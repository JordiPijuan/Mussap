﻿using MussapAutofacturacion.Business.Attributes;
using MussapAutofacturacion.Business.Contracts;
using MussapAutofacturacion.DI.Wrapper.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Business
{
    public class ScheduledProcessesProvider : IScheduledProcessesProvider
    {
        private readonly IDependenciesContainer _container;

        public ScheduledProcessesProvider(IDependenciesContainer container)
        {
            _container = container;
        }

        public IEnumerable<IScheduledProcess> GetProcesses()
        {
            var processes = Assembly
                .GetAssembly(typeof(ScheduledProcessesProvider))
                .GetTypes()
                .Where(type => Attribute.IsDefined(type, typeof(ScheduledProcessAttribute)))
                .Select(t => new
                {
                    ProcessType = t,
                    Process = _container
                        .GetInstance(t
                            .GetInterfaces()
                            .Where(i => !(i is IScheduledProcess))
                            .First()
                        ) as IScheduledProcess
                })
                .ToList();

            processes
                .Where(p => p.Process is null)
                .ToList()
                .ForEach(p => throw new InvalidCastException($"Is not possible to get instance of type {p.ProcessType}."));

            return processes
                .Select(p => p.Process);
        }
    }
}
