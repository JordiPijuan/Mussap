﻿using AutoMapper;
using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using MussapAutofacturacion.Business.Contracts;
using MussapAutofacturacion.Common;
using MussapAutofacturacion.Common.ConfigurationOptions.Contracts;
using MussapAutofacturacion.Common.ConfigurationOptions.Implementations;
using MussapAutofacturacion.Common.Exceptions;
using MussapAutofacturacion.Infrastructure.Contracts.Dtos;
using MussapAutofacturacion.Infrastructure.Contracts.Repositories;
using MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures.MussapAutofacturaStoredProcedure;
using MussapAutofacturacion.Infrastructure.NetStandard.Contexts;
using MussapAutofacturacion.Logger.Contracts;
using MussapAutofacturacion.MussapSOAPService;
using MussapAutofacturacion.MussapSOAPService.Contracts;
using Newtonsoft.Json;
using SOAPAutoFacturaPatrimonialesService;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Business
{
    public class DocumentsService : IDocumentsService
    {
      
        private readonly IApiRestClient _apiRestClient;
        private readonly IShipmentRepository _shipmentRepository;
        private readonly ILog<DocumentsService> _logger;
        private readonly IMapper _mapper;
        private readonly InterfacesContext _interfacesContext;
        private readonly DocumentsServiceProcessSettings _processSettings;
        private bool _hasErrors;

        public DocumentsService(
            IConfigOptions<HostedServicesSettings> hostedServicesSettingOptions,
            IApiRestClient apiRestClient,
            IShipmentRepository shipmentRepository,
            InterfacesContext interfacesContext,
            IMapper mapper,
            ILog<DocumentsService> logger)
        {
            _processSettings = hostedServicesSettingOptions.Value.DocumentsServiceProcessSettings;
            _apiRestClient = apiRestClient;
            _shipmentRepository = shipmentRepository;
            _interfacesContext = interfacesContext;
            _logger = logger;
            _mapper = mapper;
        }

        public Task RunAsync()
        {
            return Task.Run(() => Run());
        }

        public async Task Run()
        {
            try
            {
                lock (ApiManagement.ApiRunLock)
                {
                    var stopwatch = new Stopwatch();
                    _logger.Info($"{nameof(DocumentsService)} has started.");
                    stopwatch.Start();

                    _hasErrors = false;

                    HandleDocuments();

                    if (_hasErrors) throw new ApiClientException("There are errors on the execution.");

                    stopwatch.Stop();
                    _logger.Info($"{nameof(DocumentsService)} has finished in {stopwatch.ElapsedMilliseconds} ms.");
                    ApiManagement.RemoveFailedProcess(nameof(DocumentsService));
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"{ex.Message}", ex);
                ApiManagement.AddFailedProcess(nameof(DocumentsService), DateTime.Now, ex.Message);
                throw;
            } 
        }

        public void HandleDocuments()
        {
            ISOAPAutoFacturaPatrimonialesApi sOAPAutoFacturaPatrimonialesApi =
                new SOAPAutoFacturaPatrimonialesClient(_processSettings.MussapAutofacturacionSoapUrl, _processSettings.MussapAutofacturacionSoapUsername, _processSettings.MussapAutofacturacionSoapPassword);

            var casesToSend = _shipmentRepository.GetAutofacturaPendingsSP();
         
            foreach (var caseToSend in casesToSend)
            {
                try
                {
                    var document = CreateRequest(caseToSend);
                    DateTime sendDT = DateTime.Now;

                    var sendFacturacionResponse = Task.Run(async () => await sOAPAutoFacturaPatrimonialesApi.
                    CreaAutoFacturaAsync(document)).Result;

                    if (!sendFacturacionResponse.@return.autoFacturaAceptada)
                    {
                        var sb = new StringBuilder();
                        var errorCodes = new StringBuilder();
                        if (sendFacturacionResponse.@return.error.Any())
                        {
                            foreach (var obj in sendFacturacionResponse.@return.error)
                            {
                                errorCodes.Append(obj.errorInterno + ",");
                 
                                sb.AppendLine($"{obj.GetType().Name}: '{JsonConvert.SerializeObject(obj, Formatting.Indented)}'.");
                            }
                        }
                        _shipmentRepository.SendDataLog(caseToSend.Case_Id, caseToSend.Summary_Nu, JsonConvert.SerializeObject(document), sendDT, DateTime.Now, JsonConvert.SerializeObject(sendFacturacionResponse), errorCodes.ToString(), sb.ToString());

                        LogError(caseToSend.Case_Id, caseToSend.Summary_Nu, $"SOAPsendFacturacionResponse.@return: '{sendFacturacionResponse.@return.autoFacturaAceptada.ToString()}'", sendFacturacionResponse.@return.error);
                        continue;
                    }
                    else
                    {
                        _shipmentRepository.SendDataLog(caseToSend.Case_Id, caseToSend.Summary_Nu, JsonConvert.SerializeObject(document), sendDT, DateTime.Now, JsonConvert.SerializeObject(sendFacturacionResponse));
                        var pending = _mapper.Map<PendingSendedDto>(caseToSend);
                      
                        try
                        {
                            _shipmentRepository.DeletePendingInsertSended(pending);
                        }
                        catch (Exception ex)
                        {
                            var message = $"Failed deleting pending inserting sended. ErrorMessage: '{ex.Message}'";
                            _shipmentRepository.SendDataLog(caseToSend.Case_Id, caseToSend.Summary_Nu, JsonConvert.SerializeObject(document), sendDT, null,null,null, message);
                            LogError(caseToSend.Case_Id, caseToSend.Summary_Nu, message,  pending, ex);
                            throw new DocumentServiceException(message, ex);
                        }
                    }

                }
                catch(Exception ex) 
                {
                    LogError(caseToSend.Case_Id, caseToSend.Summary_Nu, $"Unexpected exception: '{ex.Message}'", ex);
                     continue;
                }
            }
          
        }

        private WSInfoSiniestro CreateRequest(SpMussappAutofacturacionResult autofacturacionResult)
        {
            var request = _mapper.Map<WSInfoSiniestro>(autofacturacionResult);

            /** Prueba con imagen desde filesystem **/
            //var pathToExe = Process.GetCurrentProcess().MainModule.FileName;
            //var pathToContentRoot = Path.GetDirectoryName(pathToExe);
            //var imageBytes = BitConverter.ToString(File.ReadAllBytes(pathToContentRoot + "\\image.jpg")).Replace("-",string.Empty);
            //request.docsFotografiasDanyos[0].datos = imageBytes;

            var documents =_shipmentRepository.GetRelatedFiles(autofacturacionResult.Case_Id, autofacturacionResult.Summary_Nu);
            request.docsFotografiasDanyos = _mapper.Map<WSDocumento[]>(documents);
            return request;
        }

     
        private void LogError(long caseId, int summaryNu, string message, params object[] objectsToSerialize)
        {
          
            var sb = new StringBuilder()
               .AppendLine(message)
               .AppendLine($"CaseId: '{caseId}' and SummaryNu: '{summaryNu}'.");

            if (objectsToSerialize.Any())
            {
                foreach (var obj in objectsToSerialize)
                {
                    sb.AppendLine($"{obj.GetType().Name}: '{JsonConvert.SerializeObject(obj, Formatting.Indented)}'.");
                }
            }

            _hasErrors = true;

            if (objectsToSerialize.FirstOrDefault(o => o is Exception) is Exception exception)
            {
                _logger.Error(sb.ToString(), exception);
            }
            else
            {
                _logger.Error(sb.ToString());
            }
        }

   
    }
}
