﻿using System;

namespace MussapAutofacturacion.DI.Wrapper.Contracts
{
    public interface IDependenciesContainer
    {
        TService GetInstance<TService>() where TService : class;
        object GetInstance(Type serviceType);
    }
}
