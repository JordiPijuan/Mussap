﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using MussapAutofacturacion.Common;

namespace MussapAutofacturacion.Api.Middlewares
{
    public class ApiPostEnabledMiddleware
    {
        private readonly RequestDelegate _next;
        public ApiPostEnabledMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext httpContext)
        {
            if(httpContext.Request.Method.ToUpper() == "POST" && !ApiManagement.ApiPostEnabled)
            {
                httpContext.Response.StatusCode = StatusCodes.Status503ServiceUnavailable;
                await httpContext.Response.WriteAsync("Service Unavailable");
                return;
            }
            await _next(httpContext);
        }
    }
}
