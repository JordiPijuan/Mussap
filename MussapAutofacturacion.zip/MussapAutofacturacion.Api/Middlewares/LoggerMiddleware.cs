﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using MussapAutofacturacion.Api.ApiResults;
using MussapAutofacturacion.Logger.Contracts;
using Newtonsoft.Json;

namespace MussapAutofacturacion.Api.Middlewares
{
    public class LoggerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILog<LoggerMiddleware> _logger;

        public LoggerMiddleware(RequestDelegate next, ILog<LoggerMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                _logger.Info($"Request started {httpContext.Request.Method} '{httpContext.Request.Path.ToString()}'.");
                await _next(httpContext);
                _logger.Info($"Request finished {httpContext.Request.Method} '{httpContext.Request.Path.ToString()}'.");
            }
            catch (Exception ex)
            {
                _logger.Error($"Unknown exception: {ex.Message}", ex);
                httpContext.Response.StatusCode = StatusCodes.Status500InternalServerError;

                var result = new ApiErrorResult()
                {
                    Content = null,
                    Errors = new List<string>
                    {
                        "Internal Server Error."
                    }
                };

                await httpContext.Response.WriteAsync(JsonConvert.SerializeObject(result));
                return;
            }            
        }
    }
}
