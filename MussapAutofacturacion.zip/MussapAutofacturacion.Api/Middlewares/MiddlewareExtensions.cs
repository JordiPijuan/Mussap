﻿using Microsoft.AspNetCore.Builder;

namespace MussapAutofacturacion.Api.Middlewares
{
    public static class MiddlewareExtensions
    {
        public static IApplicationBuilder UseApiPostEnabledMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ApiPostEnabledMiddleware>();
        }

        public static IApplicationBuilder UseLoggerMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<LoggerMiddleware>();
        }
    }
}
