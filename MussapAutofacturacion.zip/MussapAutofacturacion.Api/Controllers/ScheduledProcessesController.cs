﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MussapAutofacturacion.Api.ActionResults;
using MussapAutofacturacion.Api.ApiResults;
using MussapAutofacturacion.Application.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScheduledProcessesController : BaseController
    {
        private readonly IDictionary<string, ProcessDto> _processesTaskDictionary;
        private readonly IScheduledProcessesStore _scheduledProcessesStore;

        public ScheduledProcessesController(IScheduledProcessesStore scheduledProcessesStore)
        {
            _processesTaskDictionary = new Dictionary<string, ProcessDto>();
            _scheduledProcessesStore = scheduledProcessesStore;
        }

        /// <summary>
        /// Get all processes.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(IApiResult<IEnumerable<ProcessDto>>), StatusCodes.Status200OK)]
        public IActionResult GetProcesses()
        {
            var processes = _scheduledProcessesStore
                .GetProcessesDtos();

            return OkResult(processes);
        }

        /// <summary>
        /// Get a process by name.
        /// </summary>
        /// <param name="processName">Process name.</param>
        /// <returns></returns>
        [HttpGet("{processName}")]
        [ProducesResponseType(typeof(IApiResult<ProcessDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(object), StatusCodes.Status404NotFound)]
        public IActionResult GetProcess(string processName)
        {
            var process = _scheduledProcessesStore
                .GetProcessDtoByName(processName);

            if (process is null) return NotFound();

            return OkResult(process);
        }

        /// <summary>
        /// Start process by name.
        /// </summary>
        /// <param name="processName">Process name.</param>
        /// <returns></returns>
        [HttpPost("{processName}/run")]
        [ProducesResponseType(typeof(IApiResult<ProcessDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(object), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(object), StatusCodes.Status405MethodNotAllowed)]
        [ProducesResponseType(typeof(object), StatusCodes.Status503ServiceUnavailable)]
        public IActionResult Process(string processName)
        {
            var process = _scheduledProcessesStore
                .GetProcessByName(processName);

            if (process is null) return NotFound();

            if (_scheduledProcessesStore.ProcessIsRunning(process, out var processDto))
            {
                return new MethodNotAllowedResult();
            }

            var task = process
                .RunAsync();

            processDto.LastInitProcessedDate = DateTime.Now;
            processDto.Task = task;

            _scheduledProcessesStore
                .UpsertProcessDto(processDto);

            return OkResult(processDto);
        }
    }
}
