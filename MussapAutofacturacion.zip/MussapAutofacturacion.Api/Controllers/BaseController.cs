﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using MussapAutofacturacion.Api.ApiResults;

namespace MussapAutofacturacion.Api.Controllers
{
    /// <summary>
    /// Base controller provider
    /// </summary>
    public abstract class BaseController : ControllerBase
    {
        public IApiResult<TContent> ApiResult<TContent>(TContent content)
            where TContent : class
            => new ApiResult<TContent>(content);
        public IApiResult<TContent> ApiResultErrors<TContent>(TContent content, IEnumerable<string> errors)
            where TContent : class
            => new ApiResult<TContent>(content, errors);

        public IActionResult OkResult<TContent>(TContent content)
            where TContent : class
            => Ok(ApiResult(content));
        public IActionResult ConflictResult<TContent>(TContent content, IEnumerable<string> errors)
            where TContent : class
            => Conflict(ApiResultErrors(content, errors));
        public IActionResult BadRequestResult<TContent>(TContent content, IEnumerable<string> errors)
            where TContent : class
            => BadRequest(ApiResultErrors(content, errors));
    }
}
