﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MussapAutofacturacion.Api.ActionResults;
using MussapAutofacturacion.Api.ApiResults;
using MussapAutofacturacion.Application.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServicesController : BaseController
    {
        private readonly IDictionary<string, RunnableServiceDto> _processesTaskDictionary;
        private readonly IRunnableServicesStore _runnableServicesStore;

        public ServicesController(IRunnableServicesStore runnableServicesStore)
        {
            _processesTaskDictionary = new Dictionary<string, RunnableServiceDto>();
            _runnableServicesStore = runnableServicesStore;
        }

        /// <summary>
        /// Get all services.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(IApiResult<IEnumerable<RunnableServiceDto>>), StatusCodes.Status200OK)]
        public IActionResult GetServices()
        {
            var processes = _runnableServicesStore
                .GetServicesDtos();

            return OkResult(processes);
        }

        /// <summary>
        /// Get service info by name.
        /// </summary>
        /// <param name="serviceName">Service name.</param>
        /// <returns></returns>
        [HttpGet("{serviceName}")]
        [ProducesResponseType(typeof(IApiResult<RunnableServiceDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(object), StatusCodes.Status404NotFound)]
        public IActionResult GetService(string serviceName)
        {
            var process = _runnableServicesStore
                .GetServiceDtoByName(serviceName);

            if (process is null) return NotFound();

            return OkResult(process);
        }

        /// <summary>
        /// Start a service by name.
        /// </summary>
        /// <param name="serviceName">Service name.</param>
        /// <returns></returns>
        [HttpPost("{serviceName}/run")]
        [ProducesResponseType(typeof(IApiResult<RunnableServiceDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(object), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ApiErrorResult), StatusCodes.Status405MethodNotAllowed)]
        [ProducesResponseType(typeof(object), StatusCodes.Status503ServiceUnavailable)]
        public IActionResult StartService(string serviceName)
        {
            var service = _runnableServicesStore
                .GetServiceByName(serviceName);

            if (service is null) return NotFound();

            if (_runnableServicesStore.ServiceIsRunning(service, out var serviceDto))
            {
                return new MethodNotAllowedResult();
            }

            var task = service.RunAsync();

            serviceDto.LastInitProcessedDate = DateTime.Now;
            serviceDto.Task = task;

            _runnableServicesStore
                .UpsertSerciceDto(serviceDto);

            return OkResult(serviceDto);
        }
    }
}
