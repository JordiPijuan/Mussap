﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MussapAutofacturacion.Infrastructure.NetStandard.Contexts;

namespace MussapAutofacturacion.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : BaseController
    {
      //  private readonly ITokenHandler _tokenHandler;
       // private readonly IApiRestClient _apiClient;
        private readonly HomeContext _context;
        //private readonly IValidator _validator;

        public TestController( HomeContext context)
        {
            //_tokenHandler = tokenHandler;
           // _apiClient = apiClient;
            _context = context;
           // _validator = validator;
        }

        ///// <summary>
        ///// Try to get a token to test the connection.
        ///// </summary>
        ///// <returns></returns>
        //[HttpGet("token")]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //public IActionResult GetTokenTest()
        //{
        //    var token = _tokenHandler.GetToken();

        //    if (token is null) return NotFound();

        //    if (string.IsNullOrEmpty(token.AccessToken)) return NotFound();

        //    return Ok();
        //}

        /// <summary>
        /// Test authorized endpoint.
        /// </summary>
        /// <returns></returns>
        [HttpGet("authorize")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public IActionResult AuthorizeTest()
        {
            return Ok();
        }

        ///// <summary>
        ///// Test authorized endpoint.
        ///// </summary>
        ///// <returns></returns>
        //[HttpGet("sinisters/{caseId}/status")]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //[ProducesResponseType(StatusCodes.Status401Unauthorized)]
        //[ProducesResponseType(typeof(IApiResult<IApiResponse>), StatusCodes.Status200OK)]
        //public IActionResult SinisterState(long caseId)
        //{
        //    var expedient = _context
        //        .Cases
        //        .SingleOrDefault(c => c.CaseId == caseId);

        //    if (expedient is null) return NotFound();

        //    var externalCase = expedient.ExternalCase;

        //    var request = new SinisterStateRequest()
        //    {
        //        CaseId = expedient.CaseId,
        //        Year = short.Parse(externalCase.Substring(0,4)),
        //        SinisterCode = int.Parse(externalCase.Substring(4)),
        //        Company = 4,    //ToDo Get from database
        //        Department = 9  //ToDo Get from database
        //    };

        //    var response = _apiClient.Post<SinisterStateResponse>(request);

        //    return OkResult(response);
        //}

        ///// <summary>
        ///// Send sinister to MM API
        ///// </summary>
        ///// <param name="request">Sinister object</param>
        ///// <returns></returns>
        //[HttpPost("mm/endpoints/sinister/send")]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<SinisterResponse>), StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<IList<string>>), StatusCodes.Status400BadRequest)]
        //[ProducesResponseType(typeof(IApiResult<ErrorResponse>), StatusCodes.Status409Conflict)]
        //public IActionResult SendSinisterToMmApi([FromBody] SinisterRequest request)
        //{
        //    var response = SendRequestToApi<SinisterResponse>(request, out var errors);

        //    return GetActionResultEndpointCall(response, errors);
        //}

        ///// <summary>
        ///// Send service to MM API
        ///// </summary>
        ///// <param name="request">Service object</param>
        ///// <returns></returns>
        //[HttpPost("mm/endpoints/service/send")]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<ServiceResponse>), StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<IList<string>>), StatusCodes.Status400BadRequest)]
        //[ProducesResponseType(typeof(IApiResult<ErrorResponse>), StatusCodes.Status409Conflict)]
        //public IActionResult SendServiceToMmApi([FromBody] ServiceRequest request)
        //{
        //    var response = SendRequestToApi<ServiceResponse>(request, out var errors);

        //    return GetActionResultEndpointCall(response, errors);
        //}

        ///// <summary>
        ///// Send indemnification to MM API
        ///// </summary>
        ///// <param name="request">Indemnification object</param>
        ///// <returns></returns>
        //[HttpPost("mm/endpoints/indemnification/send")]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<IndemnificationResponse>), StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<IList<string>>), StatusCodes.Status400BadRequest)]
        //[ProducesResponseType(typeof(IApiResult<ErrorResponse>), StatusCodes.Status409Conflict)]
        //public IActionResult SendIndemnificationToMmApi([FromBody] IndemnificationRequest request)
        //{
        //    var response = SendRequestToApi<IndemnificationResponse>(request, out var errors);

        //    return GetActionResultEndpointCall(response, errors);
        //}

        ///// <summary>
        ///// Send complaint to MM API
        ///// </summary>
        ///// <param name="request">Complaint object</param>
        ///// <returns></returns>
        //[HttpPost("mm/endpoints/complaint/send")]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<ComplaintResponse>), StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<IList<string>>), StatusCodes.Status400BadRequest)]
        //[ProducesResponseType(typeof(IApiResult<ErrorResponse>), StatusCodes.Status409Conflict)]
        //public IActionResult SendComplaintToMmApi([FromBody] ComplaintRequest request)
        //{
        //    var response = SendRequestToApi<ComplaintResponse>(request, out var errors);

        //    return GetActionResultEndpointCall(response, errors);
        //}

        ///// <summary>
        ///// Send recobro to MM API
        ///// </summary>
        ///// <param name="request">Recobro object</param>
        ///// <returns></returns>
        //[HttpPost("mm/endpoints/recobro/send")]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<RecobroResponse>), StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(IApiResult<IList<string>>), StatusCodes.Status400BadRequest)]
        //[ProducesResponseType(typeof(IApiResult<ErrorResponse>), StatusCodes.Status409Conflict)]
        //public IActionResult SendRecobroToMmApi([FromBody] RecobroRequest request)
        //{
        //    var response = SendRequestToApi<RecobroResponse>(request, out var errors);

        //    return GetActionResultEndpointCall(response, errors);
        //}

        //private IApiResponse SendRequestToApi<TResponse>(IApiRequest request, out List<string> errors)
        //    where TResponse : IApiResponse
        //{
        //    errors = new List<string>();
        //    var validationResults = _validator.Validate(request);
            
        //    if (!validationResults.IsValid)
        //    {
        //        errors = validationResults
        //            .Errors
        //            .GetErrorsDescriptionList()
        //            .ToList();            

        //        return null;
        //    }

        //    try
        //    {
        //        return _apiClient.Post<TResponse>(request);
        //    }
        //    catch (Exception ex)
        //    {
        //        errors = GetFullExceptionsMessage(ex);
        //        return null;
        //    }
        //}

        //private List<string> GetFullExceptionsMessage(Exception ex, List<string> messages = null)
        //{
        //    if(messages is null) messages = new List<string>();

        //    messages.Add(ex.Message);

        //    if (ex.InnerException is null)
        //    {
        //        return messages;
        //    }
        //    return GetFullExceptionsMessage(ex.InnerException, messages);
        //}

        //private IActionResult GetActionResultEndpointCall(IApiResponse response, List<string> errors)
        //{
        //    if (response is null) return BadRequestResult<object>(null, errors);

        //    if (response is ErrorResponse errorResponse)
        //    {
        //        errors.Add($"{nameof(ErrorResponse.IncidenceCode)}: '{errorResponse.IncidenceCode}'");
        //        errors.Add($"{nameof(ErrorResponse.ErrorDescription)}: '{errorResponse.ErrorDescription}'");

        //        return ConflictResult(response, errors);
        //    }

        //    return OkResult(response);
        //}
    }
}
