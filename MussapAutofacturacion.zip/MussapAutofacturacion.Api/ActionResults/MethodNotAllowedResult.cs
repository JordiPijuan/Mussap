﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MussapAutofacturacion.Api.ApiResults;

namespace MussapAutofacturacion.Api.ActionResults
{
    public class MethodNotAllowedResult : IActionResult
    {
        private readonly IApiResult<object> _result;

        public MethodNotAllowedResult(IApiResult<object> result)
        {
            _result = result;
        }

        public MethodNotAllowedResult()
        {
            _result = new ApiErrorResult()
            {
                Content = null,
                Errors = new List<string>
                {
                    "405 Method Not Allowed.",
                    "The request method is known by the server but is not supported by the target resource."
                }
            };
        }

        public async Task ExecuteResultAsync(ActionContext context)
        {
            var objectResult = new ObjectResult(_result)
            {
                StatusCode = StatusCodes.Status405MethodNotAllowed
            };

            await objectResult.ExecuteResultAsync(context);
        }
    }
}
