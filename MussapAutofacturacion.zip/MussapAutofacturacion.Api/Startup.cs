﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using AutoMapper;
using log4net;
using log4net.Config;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MussapAutofacturacion.Api.Middlewares;
using MussapAutofacturacion.Api.Security;
using MussapAutofacturacion.ApiClient.Contracts.RestClient;
using MussapAutofacturacion.ApiClient.Models;
using MussapAutofacturacion.ApiClient.RestClient;
using MussapAutofacturacion.Application;
using MussapAutofacturacion.Application.Contracts;
using MussapAutofacturacion.Business;
using MussapAutofacturacion.Business.Contracts;
using MussapAutofacturacion.Business.ScheduledProcesses;
using MussapAutofacturacion.Common;
using MussapAutofacturacion.Common.ConfigurationOptions;
using MussapAutofacturacion.Common.ConfigurationOptions.Contracts;
using MussapAutofacturacion.Common.ConfigurationOptions.Implementations;
using MussapAutofacturacion.DI.Wrapper;
using MussapAutofacturacion.DI.Wrapper.Contracts;
using MussapAutofacturacion.FileWriter;
using MussapAutofacturacion.FileWriter.Contracts;
using MussapAutofacturacion.Infrastructure.Contracts.Repositories;
using MussapAutofacturacion.Infrastructure.NetStandard.Contexts;
using MussapAutofacturacion.Infrastructure.NetStandard.Repositories;
using MussapAutofacturacion.Logger;
using MussapAutofacturacion.Logger.Contracts;
using Swashbuckle.AspNetCore.Swagger;


namespace MussapAutofacturacion.Api
{
    public class Startup
    {
        public Startup(IWebHostEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile($"appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();

            Configuration = builder.Build(); // configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddDbContext<InterfacesContext>(options =>
                 options.UseSqlServer(Configuration.GetConnectionString(nameof(InterfacesContext)),
                    optionsBuilder => optionsBuilder.EnableRetryOnFailure()));


            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));


            CrosscuttingRegistrations(services);
            DalInfrastructureRegistrations(services);
            BusinessServicesRegistrations(services);
           ApplicationRegistrations(services);
           RegisterHostedServices(services);
            RegisterMappings();
            services.AddMvcCore();
             
            services.AddAutoMapper(
                cfg =>
                {
                    cfg.AddProfile<Business.Mappings.MapperProfile>();
                    cfg.AddProfile<ApiClient.Mapping.MapperProfile>();
                    cfg.AddProfile<Infrastructure.Mappings.MapperProfile>();
                });
            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "MUSSAP Autofacturacion API", Version = "v1" });

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.XML";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);

                c.IncludeXmlComments(xmlPath);
            });
           
     

            // Register the Swagger generator, defining 1 or more Swagger documents
            //services.AddSwaggerGen(c =>
            //{
            //    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "MUSSAP Autofacturacion API", Version = "v1" });

            // var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.XML";
            //var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);

            //c.IncludeXmlComments(xmlPath);
        }

        private void RegisterHostedServices(IServiceCollection services)
        {
            var hostedServicesSettingsSection = Configuration
                .GetSection(nameof(HostedServicesSettings));

            var documentsServiceProcessSection = hostedServicesSettingsSection
                .GetSection(nameof(DocumentsServiceProcessSettings));

            var apiStatusCheckerProcessSection = hostedServicesSettingsSection
                .GetSection(nameof(ApiStatusCheckerSettings));

            //var monitoringValidationProcessEnabled = Convert
            //    .ChangeType(monitoringValidationProcessSection[nameof(MonitoringValidationProcessSettings.Enabled)], typeof(bool)) as bool?;
         
            var apiStatusCheckerProcessEnabled = Convert
                .ChangeType(apiStatusCheckerProcessSection[nameof(ApiStatusCheckerSettings.Enabled)], typeof(bool)) as bool?;

            var documentsServiceProcessEnabled = Convert
                .ChangeType(documentsServiceProcessSection[nameof(DocumentsServiceProcessSettings.Enabled)], typeof(bool)) as bool?;

            
            if (documentsServiceProcessEnabled == true)
            {
                services.AddHostedService<DocumentsBackgroundService>();
            }

            if (apiStatusCheckerProcessEnabled == true)
            {
                services.AddHostedService<ApiStatusCheckerBackgroundService>();
            }
        }

        #region DI Registrations

        private void CrosscuttingRegistrations(IServiceCollection services)
        {
            services.AddTransient(typeof(IConfigOptions<>), typeof(OptionsConfiguration<>));
            services.AddTransient(typeof(ILog<>), typeof(Log<>));
            services.AddScoped<ITokenHandler, TokenHandler>();
            services.AddScoped<IFileWriter, FileWriter.FileWriter>();
            services.AddScoped<IRequestResponseFileWriter, RequestResponseFileWriter>();
            services.AddScoped<IApiRestClient, ApiRestClient>();
            services.AddSingleton<IDependenciesContainer>(s => new DependenciesContainer(services));
        }

        private void DalInfrastructureRegistrations(IServiceCollection services)
        {
            services.AddScoped(typeof(IGenericRepository<,>), typeof(GenericRepository<,>));
            services.AddScoped<IShipmentRepository, ShipmentRepository>();
  
        }

        private void BusinessServicesRegistrations(IServiceCollection services)
        {
          

            services.AddTransient<IScheduledProcessesProvider, ScheduledProcessesProvider>();
            services.AddScoped<IDocumentsService, DocumentsService>();
            //services.AddTransient<IMonitoringValidationProcess, MonitoringValidationProcess>();
        }

        private void ApplicationRegistrations(IServiceCollection services)
        {
            services.AddSingleton<IRunnableServicesStore, RunnableServicesStore>();
            services.AddSingleton<IScheduledProcessesStore, ScheduledProcessesStore>();
        }

        #endregion

        public static void RegisterMappings()
        {
            //Mapper.Initialize(cfg =>
            //{
            //    //cfg.AddProfile<ApiClient.Mappings.MapperProfile>();
            //    cfg.AddProfile<Infrastructure.Mappings.MapperProfile>();
            //   // cfg.AddProfile<Business.Mappings.MapperProfile>();
            //   // cfg.AddProfile<Business.ScheduledProcesses.Mappings.MapperProfile>();
            //   // cfg.AddProfile<MailSender.Mappings.MapperProfile>();
            //});
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                //app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            // Enable middleware to serve generated Swagger as a JSON endpoint
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), 
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Mussap Autofacturacion API V1");
                c.DocumentTitle = "Mussap Swagger";
            });
            app.UseStaticFiles();
            app.UseRouting();
            app.UseEndpoints(enpoints =>
            {
                enpoints.MapControllers();
            });
            app.UseHttpsRedirection();
            app.UseLoggerMiddleware();
            app.UseApiPostEnabledMiddleware();

            //app.UseAuthentication();
          
           // app.UseMvc(  );
        }
    }
}
