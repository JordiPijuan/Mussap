﻿using System.Collections.Generic;

namespace MussapAutofacturacion.Api.ApiResults
{
    public class ApiErrorResult : IApiResult<object>
    {
        public IEnumerable<string> Errors { get; set; }
        public object Content { get; set; }

    }
}
