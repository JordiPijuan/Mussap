﻿using System;

namespace MussapAutofacturacion.Api.ApiResults
{
    public class ApiProcessFailure
    {
        public string ProcessName { get; set; }
        public DateTime Date { get; set; }
        public string ErrorMessage { get; set; }
    }
}
