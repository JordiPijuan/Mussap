﻿using System.Collections.Generic;

namespace MussapAutofacturacion.Api.ApiResults
{
    public interface IApiResult<TContent>
    {
        IEnumerable<string> Errors { get; set; }
        TContent Content { get; set; }
    }
}