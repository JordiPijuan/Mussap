﻿using System.Collections.Generic;

namespace MussapAutofacturacion.Api.ApiResults
{
    public class ApiResult<TContent> : IApiResult<TContent> 
        where TContent : class
    {
        public IEnumerable<string> Errors { get; set; }
        public TContent Content { get; set; }

        public ApiResult(TContent content)
        {
            Content = content;
        }

        public ApiResult(TContent content, IEnumerable<string> errors)
        {
            Content = content;
            Errors = errors;
        }
    }
}