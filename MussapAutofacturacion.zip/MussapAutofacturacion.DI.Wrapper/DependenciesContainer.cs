﻿using System;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;
using MussapAutofacturacion.DI.Wrapper.Contracts;
using SimpleInjector;

namespace MussapAutofacturacion.DI.Wrapper
{
    public class DependenciesContainer : IDependenciesContainer
    {
        private readonly Container _container;
        private readonly IServiceProvider _serviceProvider;
       
        public DependenciesContainer(Container container) => _container = container;
        public DependenciesContainer(IServiceCollection services) => _serviceProvider = services.BuildServiceProvider();

        public TService GetInstance<TService>() 
            where TService : class => GetServiceInstance<TService>();

        public object GetInstance(Type serviceType) => GetServiceInstance(serviceType);

        private TService GetServiceInstance<TService>() 
            where TService : class
        {
            try
            {
                if (_container != null) return _container.GetInstance<TService>();

                if (_serviceProvider != null)
                {
                    var service = _serviceProvider.GetService<TService>();
                    if (service is null)
                    {
                        var serviceType = typeof(TService);
                        service = GetServiceInstanceDirectInterface(typeof(TService)) as TService;

                        if (service is null)
                        {
                            service = GetServiceInstanceFirstInterface(typeof(TService)) as TService;
                        }
                    }
                    if (service != null)
                    {
                        return service;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"DependenciesContainerException: Error getting service of type: '{typeof(TService).Name}'.", ex);
            }
            throw new Exception($"DependenciesContainerException: Error getting service of type: '{typeof(TService).Name}'.");
        }

        private object GetServiceInstance(Type serviceType)
        {
            try
            {
                if (_container != null) return _container.GetInstance(serviceType);

                if (_serviceProvider != null)
                {
                    var service = _serviceProvider.GetService(serviceType);

                    if (service is null)
                    {
                        service = GetServiceInstanceDirectInterface(serviceType);

                        if (service is null)
                        {
                            service = GetServiceInstanceFirstInterface(serviceType);
                        }
                    }
                    if (service != null)
                    {
                        return service;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"DependenciesContainerException: Error getting service of type: '{serviceType.Name}'.", ex);
            }

            throw new Exception($"DependenciesContainerException: Error getting service of type: '{serviceType.Name}'.");
        }

        private object GetServiceInstanceDirectInterface(Type serviceType)
        {
            var serviceDirectInterface = serviceType
                .GetInterface($"I{serviceType.Name}");

            return _serviceProvider.GetService(serviceDirectInterface);
        }

        private object GetServiceInstanceFirstInterface(Type serviceType)
        {
            var serviceFirstInterface = serviceType
                .GetInterfaces()
                .FirstOrDefault();

            return _serviceProvider.GetService(serviceFirstInterface);
        }
    }
}
