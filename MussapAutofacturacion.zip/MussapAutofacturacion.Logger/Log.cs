﻿using System;
using System.Runtime.CompilerServices;
using log4net;
using MussapAutofacturacion.Logger.Contracts;

namespace MussapAutofacturacion.Logger
{
    public class Log<T> : ILog<T> 
        where T : class
    {
        private readonly string _className;

        public Log()
        {
            _className = typeof(T).FullName;
        }

        private ILog GetLog()
            => LogManager.GetLogger(typeof(T));

        private string CompositeMessage(string message, string memberName, int sourceLineNumber) 
            => $" > [Method: '{memberName}', Line: '{sourceLineNumber}'] > {message}";

        public void Debug(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0) 
            => GetLog()
                .Debug(CompositeMessage(message, memberName, sourceLineNumber));

        public void Error(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0)
            => GetLog()
                .Error(CompositeMessage(message, memberName, sourceLineNumber));

        public void Error(string message, Exception exception, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0)
            => GetLog()
                .Error(CompositeMessage(message, memberName, sourceLineNumber), exception);

        public void Fatal(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0)
            => GetLog()
                .Fatal(CompositeMessage(message, memberName, sourceLineNumber));

        public void Fatal(string message, Exception exception, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0)
            => GetLog()
                .Fatal(CompositeMessage(message, memberName, sourceLineNumber), exception);

        public void Info(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0)
            => GetLog()
                .Info(CompositeMessage(message, memberName, sourceLineNumber));

        public void Warning(string message, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0)
            => GetLog()
                .Warn(CompositeMessage(message, memberName, sourceLineNumber));

        public void Warning(string message, Exception exception, [CallerMemberName] string memberName = "", [CallerLineNumber] int sourceLineNumber = 0)
            => GetLog()
                .Warn(CompositeMessage(message, memberName, sourceLineNumber), exception);
    }
}
