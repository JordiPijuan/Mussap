﻿using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;

namespace MussapAutofacturacion.Logger
{
    public class EfCoreLoggerProvider : ILoggerProvider
    {
        private readonly ConcurrentDictionary<string, ILogger> _loggers;

        public EfCoreLoggerProvider(ILogger logger)
        {
            _loggers = new ConcurrentDictionary<string, ILogger>();
        }

        public ILogger CreateLogger(string categoryName)
        {
            return _loggers.GetOrAdd(categoryName, name => new EfCoreLogger());
        }

        public void Dispose()
        {
            _loggers.Clear();
        }
    }
}
