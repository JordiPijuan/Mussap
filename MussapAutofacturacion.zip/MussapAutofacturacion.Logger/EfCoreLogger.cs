﻿using System;
using Microsoft.Extensions.Logging;

namespace MussapAutofacturacion.Logger
{
    public class EfCoreLogger : Log<EfCoreLogger>, ILogger
    {

        public EfCoreLogger()
        {
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            if (!IsEnabled(logLevel))
            {
                return;
            }
                       
            switch (logLevel)
            {
                case LogLevel.Trace:
                    Debug($"{logLevel.ToString()} - {eventId.Id} - {formatter(state, exception)}");
                    break;
                case LogLevel.Debug:
                    Debug($"{eventId.Id} - {formatter(state, exception)}");
                    break;
                case LogLevel.Information:
                    Info($"{eventId.Id} - {formatter(state, exception)}");
                    break;
                case LogLevel.Warning:
                    Warning($"{eventId.Id} - {formatter(state, exception)}");
                    break;
                case LogLevel.Error:
                    Error($"{eventId.Id} - {formatter(state, exception)}");
                    break;
                case LogLevel.Critical:
                    Fatal($"{eventId.Id} - {formatter(state, exception)}");
                    break;
                case LogLevel.None:
                    Debug($"{logLevel.ToString()} - {eventId.Id} - {formatter(state, exception)}");
                    break;
                default:
                    Debug($"{logLevel.ToString()} - {eventId.Id} - {formatter(state, exception)}");
                    break;
            }
        }

        IDisposable ILogger.BeginScope<TState>(TState state)
        {
            return null;
        }
    }
}
