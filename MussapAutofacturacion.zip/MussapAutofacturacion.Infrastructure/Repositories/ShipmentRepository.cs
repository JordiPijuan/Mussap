﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Transactions;
using System.Xml;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Dapper;
using Microsoft.EntityFrameworkCore;
using MussapAutofacturacion.Common;
using MussapAutofacturacion.Common.Enums;
using MussapAutofacturacion.Common.Exceptions;
using MussapAutofacturacion.Entities.Interfaces;
using MussapAutofacturacion.Infrastructure.Contracts.Dtos;
using MussapAutofacturacion.Infrastructure.Contracts.Repositories;
using MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures;
using MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures.MussapAutofacturaStoredProcedure;
using MussapAutofacturacion.Infrastructure.NetStandard.Contexts;
using MussapAutofacturacion.Logger.Contracts;
using Newtonsoft.Json;

namespace MussapAutofacturacion.Infrastructure.NetStandard.Repositories
{
    public class ShipmentRepository : IShipmentRepository
    {
     
        private readonly ILog<ShipmentRepository> _logger;
        private readonly InterfacesContext _interfacesContext;
        private readonly IMapper _mapper;
        private readonly object _lock = new object();

        private const string _shipmentPendingTable = "[INTERFACES].[online].[SHIPMENT_PENDING__R__CASE_SUMMARY]";
        private const string _shipmentSendedTable = "[INTERFACES].[online].[SHIPMENT_SENDED__R__CASE_SUMMARY]";
        private const string _musappShipmentAutofacturaSP = "[INTERFACES].[mussap].[SPR_CREAAUTOFACTURA]";
        private const string _mussapShipmentRelatedFilesSP = "[INTERFACES].[mussap].[SPR_RELATED_FILES] @pCASE_ID,  @pSUMMARY_NU";
        private const string _mussapSendDataSP = "[INTERFACES].[mussap].[SPI_MUSSAP_SEND]  @pCASE_ID, @pSUMMARY_NU, @pSEND_DT, @pSEND_DATA, @pRECEPTION_DT, @pRECEPTION_DATA, @pRECEPTION_ERROR_CODE,@pRECEPTION_ERROR_DESCRIPTION";

        public ShipmentRepository(
            InterfacesContext interfacesContext,
            ILog<ShipmentRepository> logger,
            IMapper mapper
            )
        {

            _interfacesContext = interfacesContext;
            _logger = logger;
            _mapper = mapper;
        }

        public IEnumerable<SpMussappAutofacturacionResult> GetAutofacturaPendingsSP()
        {
            var result = _interfacesContext.Set<SpMussappAutofacturacionResult>()
                   .FromSqlRaw("EXEC " + _musappShipmentAutofacturaSP)
                   .AsEnumerable()
                   .ToList();
            return result;
        }

        public void SendDataLog(long caseId, int summaryNu,string sendData,DateTime sendDT, DateTime? receptionDT = null,string receptionData = null,string receptionErrorCode =null , string receptionErrorDescription = null )
        {
            var connectionString = _interfacesContext.Database.GetDbConnection().ConnectionString;

            var parameters = new[] {
                new Microsoft.Data.SqlClient.SqlParameter("@pCASE_ID",caseId),
                new Microsoft.Data.SqlClient.SqlParameter("@pSUMMARY_NU",summaryNu),
                new Microsoft.Data.SqlClient.SqlParameter("@pSEND_DT",sendDT),
                new Microsoft.Data.SqlClient.SqlParameter("@pSEND_DATA",sendData),
                new Microsoft.Data.SqlClient.SqlParameter("@pRECEPTION_DT",(object)receptionDT??DBNull.Value),
                new Microsoft.Data.SqlClient.SqlParameter("@pRECEPTION_DATA",(object)receptionData??DBNull.Value),
                new Microsoft.Data.SqlClient.SqlParameter("@pRECEPTION_ERROR_CODE",(object)receptionErrorCode??DBNull.Value),
                new Microsoft.Data.SqlClient.SqlParameter("@pRECEPTION_ERROR_DESCRIPTION",(object)receptionErrorDescription??DBNull.Value)
            };

            try
            {

                  _interfacesContext.Database.ExecuteSqlRaw("EXEC " + _mussapSendDataSP, parameters);
        
            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine("Failed execute SP [mussap].[SPI_MUSSAP_SEND]");

                throw new SqlDapperException(sb.ToString(), ex);
            }

        }
        public IEnumerable<SpMussappRelatedFilesResult> GetRelatedFiles(long caseId, int summaryNu)
        {
            var parameters = new[] {
                new Microsoft.Data.SqlClient.SqlParameter("@pCASE_ID",caseId),
                new Microsoft.Data.SqlClient.SqlParameter("@pSUMMARY_NU",summaryNu)
            };

            var result = _interfacesContext.Set<SpMussappRelatedFilesResult>()
                   .FromSqlRaw("EXEC " + _mussapShipmentRelatedFilesSP, parameters)
                   .AsEnumerable()
                   .ToList();
            return result;
        }


        public void DeletePendingInsertSended(PendingSendedDto pendingSendedDto)
        {
            lock (_lock)
            {
                var connectionstring = _interfacesContext.Database.GetDbConnection().ConnectionString;

                var pending = GetPending(pendingSendedDto);

                if (pending is null)
                {
                    _logger.Debug($"Not found pending with CaseId: '{pendingSendedDto.CaseId}', SummaryNu: '{pendingSendedDto.SummaryNu}' and ShipmentId: '{pendingSendedDto.ShipmentId}'.");
                    return;
                }

                var sended = _mapper.Map<ShipmentSendedRCaseSummary>(pending);

                MoveSendedToPending(pending, sended);

                _logger.Info($"Moved from pending to sended movement with CaseId: '{pendingSendedDto.CaseId}' and SummaryNu: '{pendingSendedDto.SummaryNu}'.");
            }
        }

        private ShipmentPendingRCaseSummary GetPending(PendingSendedDto pendingSendedDto)
        {
            var connectionString = _interfacesContext.Database.GetDbConnection().ConnectionString;

            var sb = new StringBuilder();
            sb.AppendLine("SELECT ")
                .AppendLine($"CASE_ID {nameof(ShipmentPendingRCaseSummary.CaseId)},")
                .AppendLine($"SUMMARY_NU {nameof(ShipmentPendingRCaseSummary.SummaryNu)},")
                .AppendLine($"SHIPMENT_ID {nameof(ShipmentPendingRCaseSummary.ShipmentId)},")
                .AppendLine($"CREATED_ID {nameof(ShipmentPendingRCaseSummary.CreatedId)},")
                .AppendLine($"CREATE_DT {nameof(ShipmentPendingRCaseSummary.CreatedDate)},")
                .AppendLine($"PRIORITY_NU {nameof(ShipmentPendingRCaseSummary.Priority)}")
                .AppendLine($"FROM {_shipmentPendingTable}")
                .AppendLine($"WHERE CASE_ID = {pendingSendedDto.CaseId}")
                .AppendLine($"AND SUMMARY_NU = {pendingSendedDto.SummaryNu}")
                .AppendLine($"AND SHIPMENT_ID = {pendingSendedDto.ShipmentId}");

            var sqlSentence = sb.ToString();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    var entities = connection.Query<ShipmentPendingRCaseSummary>(sqlSentence);
                    return entities.SingleOrDefault();
                }
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed executing query: {Environment.NewLine}'{sqlSentence}'.";
                _logger.Error(errorMessage);
                throw new SqlDapperException(errorMessage, ex);
            }
        }
        private void MoveSendedToPending(ShipmentPendingRCaseSummary pending, ShipmentSendedRCaseSummary sended)
        {
            var connectionString = _interfacesContext.Database.GetDbConnection().ConnectionString;

            var insertQuery = new StringBuilder();
            insertQuery.AppendLine($"INSERT INTO {_shipmentSendedTable} (CASE_ID, SUMMARY_NU, SHIPMENT_ID, CREATED_ID, CREATE_DT, SEND_ID, SEND_DT)")
                .AppendLine($"VALUES (")
                .AppendLine($"{sended.CaseId},")
                .AppendLine($"{sended.SummaryNu},")
                .AppendLine($"{sended.ShipmentId},")
                .AppendLine($"{sended.CreatedId},")
                .AppendLine($"'{sended.CreatedDate:yyyy-MM-dd HH:mm:ss.fff}',")
                .AppendLine($"{sended.SendId},")
                .AppendLine($"'{sended.SendDate:yyyy-MM-dd HH:mm:ss.fff}'")
                .AppendLine($");");

            var deleteQuery = new StringBuilder();
            deleteQuery.AppendLine($"DELETE FROM {_shipmentPendingTable}")
                .AppendLine($"WHERE CASE_ID = {pending.CaseId}")
                .AppendLine($"AND SUMMARY_NU = {pending.SummaryNu}")
                .AppendLine($"AND SHIPMENT_ID = {pending.ShipmentId};");

            try
            {
                using (var transaction = new TransactionScope())
                {
                    using (var connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        connection.Execute(insertQuery.ToString(), transaction);
                        var deleteRowsAffected = connection.Execute(deleteQuery.ToString(), transaction);

                        if (deleteRowsAffected != 1)
                            throw new SqlDapperException($"The query expected 1 row affected and the current value is '{deleteRowsAffected}' for the query: {Environment.NewLine}'{deleteQuery}'.");
                    }
                    transaction.Complete();
                }
            }
            catch (Exception ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine("Failed moving sended to pending.")
                    .AppendLine($"Insert query: '{insertQuery}'.")
                    .AppendLine($"Delete query: '{deleteQuery}'.");

                throw new SqlDapperException(sb.ToString(), ex);
            }
        }
    }
}
