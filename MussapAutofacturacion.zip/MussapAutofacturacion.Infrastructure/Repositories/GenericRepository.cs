﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MussapAutofacturacion.DI.Wrapper.Contracts;
using MussapAutofacturacion.Entities;
using MussapAutofacturacion.Infrastructure.Contracts.Repositories;
using MussapAutofacturacion.Infrastructure.NetStandard.UnitOfWork;
using MussapAutofacturacion.Logger.Contracts;
//using Newtonsoft.Json;

namespace MussapAutofacturacion.Infrastructure.NetStandard.Repositories
{
    public class GenericRepository<TEntity, TContext> : UnitOfWork<TContext>, IGenericRepository<TEntity, TContext>
        where TEntity : EntityBase
        where TContext : DbContext
    {
        private DbSet<TEntity> DbSet;
        private readonly object _lock = new object();
        
        public GenericRepository(ILog<UnitOfWork<TContext>> unitOfWorkLogger, TContext context, IDependenciesContainer container) : base(unitOfWorkLogger)
        {
            Context = container.GetInstance<TContext>();
            DbSet = Context.Set<TEntity>();
        }

        public virtual IQueryable<TEntity> GetAll() 
            => DbSet.AsQueryable();

        public virtual IQueryable<TEntity> GetByFilter(Expression<Func<TEntity, bool>> filter)
        {
            return DbSet.Where(filter);
        }

        [Obsolete]
        public virtual void Add(TEntity obj)
        {
            lock (_lock)
            {
                var added = DbSet.Add(obj);

                Save();
            }
        }

        public virtual TEntity AddV2(TEntity obj)
        {
            lock (_lock)
            {
                var entry = DbSet.Add(obj);

                Save();

                if (entry.State != EntityState.Added)
                {
                   // Logger.Error($"Entity not added. TEntity: '{obj.GetType()}', Json: '{JsonConvert.SerializeObject(obj)}'");
                }

                return entry.Entity;
            }
        }

        public virtual void AddRange(IEnumerable<TEntity> entities)
        {
            lock (_lock)
            {
                DbSet.AddRange(entities);

                Save();
            }
        }

        public virtual void Update(TEntity obj)
        {
            lock (_lock)
            {
                DbSet.Attach(obj);
                Context.Entry(obj).State = EntityState.Modified;

                Save();
            }
        }

        public virtual void UpdateChanges(TEntity obj)
        {
            lock (_lock)
            {
                DbSet.Attach(obj);
                //Context
                //    .Entry(obj)
                //    .Property(propertyExpression)
                //    .IsModified = true;

                Save();
            }
        }

        public virtual void Update(IEnumerable<TEntity> entities)
        {
            lock (_lock)
            {
                if (entities.Any())
                {
                    foreach (var entity in entities)
                    {
                        DbSet.Attach(entity);
                        Context.Entry(entity).State = EntityState.Modified;
                    }

                    Save();
                }
            }
        }

        public virtual void UpdateRangeChanges(IEnumerable<TEntity> entities)
        {
            lock (_lock)
            {
                if (entities.Any())
                {
                    foreach (var entity in entities)
                    {
                        lock (_lock)
                        {
                            DbSet.Attach(entity);
                            //Context
                            //    .Entry(entity)
                            //    .Property(propertyExpression)
                            //    .IsModified = true;
                        }
                    }

                    Save();
                }
            }
        }

        public virtual void Delete(object Id)
        {
            lock (_lock)
            {
                TEntity entity = DbSet.Find(Id);
                DbSet.Remove(entity);

                Save();
            }
        }
        
        public virtual void Delete(IEnumerable<TEntity> entities)
        {
            lock (_lock)
            {
                DbSet.RemoveRange(entities);

                Save();
            }
        }

        public virtual void Save()
        {
            Commit();
        }

        public virtual async Task<int> SaveAsync()
        {
            return await CommitAsync();
        }
    }
}
