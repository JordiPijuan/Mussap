﻿using System;
using AutoMapper;
using MussapAutofacturacion.Common;
using MussapAutofacturacion.Common.Enums;
using MussapAutofacturacion.Entities.Interfaces;


namespace MussapAutofacturacion.Infrastructure.Mappings
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<ShipmentPendingRCaseSummary, ShipmentSendedRCaseSummary>()
                      .ForMember(dest => dest.SendId,
                                  opts => opts.MapFrom(src => 1)) 
                      .ForMember(dest => dest.SendDate,
                                  opts => opts.MapFrom(src => DateTime.Now));

            CreateMap<ShipmentPendingRCaseSummary, ShipmentPendingDeleteRCaseSummary>()
                    .ForMember(dest => dest.Stored,
                        opts => opts.MapFrom(src => string.Empty))
                    .ForMember(dest => dest.Text,
                        opts => opts.MapFrom(src => string.Empty))
                    .ForMember(dest => dest.DeletedId,
                        opts => opts.MapFrom(src => UserSessions.Default))
                     .ForMember(dest => dest.DeletedDate,
                        opts => opts.MapFrom(src => DateTime.Now));
           
        }

        private (int sendType, string sendModo, string modifType) ConvertSummaryType(long summaryTypeId)
        {
            var summaryType = (SummaryTypes) summaryTypeId;

            return SummaryTypeConvert.GetSummaryTypeData(summaryType);
        }
    }
}
