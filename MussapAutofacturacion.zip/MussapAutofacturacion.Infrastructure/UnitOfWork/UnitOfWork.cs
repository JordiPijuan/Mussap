﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MussapAutofacturacion.Infrastructure.Contracts.UnitOfWork;
using MussapAutofacturacion.Logger.Contracts;

namespace MussapAutofacturacion.Infrastructure.NetStandard.UnitOfWork
{
    public class UnitOfWork<TContext> : IUnitOfWork
        where TContext : DbContext
    {
        protected readonly ILog<UnitOfWork<TContext>> Logger;

        public UnitOfWork(ILog<UnitOfWork<TContext>> logger)
        {
            Logger = logger;
        }

        public TContext Context { get; set; }
        public int Commit()
        {
            try
            {
                CheckContextIsNotNull();
                return Context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                // Update the values of the entity that failed to save from the store
                ex.Entries.Single().Reload();
                Logger.Error("DbUpdateConcurrencyException", ex);
                return 1;
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message, ex);
                throw;
            }
        }

        public async Task<int> CommitAsync()
        {
            try
            {
                CheckContextIsNotNull();
                return await Context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                // Update the values of the entity that failed to save from the store
                ex.Entries.Single().Reload();
                return 1;
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message, ex);
                throw;
            }
        }

        public void CheckContextIsNotNull()
        {
            if (Context is null)
                throw new NullReferenceException($"UnitOfWork. The property '{nameof(Context)}' of type '{typeof(TContext)}' is null.");
        }

    }
}
