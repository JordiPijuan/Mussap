﻿using System;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Infrastructure.Contracts.UnitOfWork
{
    public interface IUnitOfWork
    {
        int Commit();
        Task<int> CommitAsync();
    }
}
