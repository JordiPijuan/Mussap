﻿using System;

namespace MussapAutofacturacion.Infrastructure.Contracts.Dtos
{
    public class UpdateCaseDto
    {
        public long CaseId { get; set; }
        public int SinisterCode { get; set; }
        public int SummaryNu { get; set; }
        public string SendType { get; set; }
        public DateTime SendDate { get; set; }
        public string RdoYear { get; set; }
    }
}
