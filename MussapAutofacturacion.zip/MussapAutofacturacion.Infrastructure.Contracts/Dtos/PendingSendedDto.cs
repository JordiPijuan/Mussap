﻿namespace MussapAutofacturacion.Infrastructure.Contracts.Dtos
{
    public class PendingSendedDto
    {
        public long CaseId { get; set; }
        public int SummaryNu { get; set; }
        public int ShipmentId { get; set; }
    }
}
