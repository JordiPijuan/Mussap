﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using MussapAutofacturacion.Entities;
using MussapAutofacturacion.Infrastructure.Contracts.UnitOfWork;

namespace MussapAutofacturacion.Infrastructure.Contracts.Repositories
{
    public interface IGenericRepository<TEntity, TContext> : IUnitOfWork
            where TEntity : EntityBase
    {
        IQueryable<TEntity> GetAll();
        IQueryable<TEntity> GetByFilter(Expression<Func<TEntity, bool>> filter);
        void Add(TEntity obj);
        TEntity AddV2(TEntity obj);
        void AddRange(IEnumerable<TEntity> entities);
        //Task AddRangeAsync(IEnumerable<TEntity> entities);
        void Update(TEntity obj);
        void UpdateChanges(TEntity obj);
        void Update(IEnumerable<TEntity> entities);
        void UpdateRangeChanges(IEnumerable<TEntity> entities);
        void Delete(object Id);
        void Delete(IEnumerable<TEntity> entities);
        void Save();
    }
}
