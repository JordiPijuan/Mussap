﻿using System;
using System.Collections.Generic;
using System.Xml;
using MussapAutofacturacion.Infrastructure.Contracts.Dtos;
using MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures;
using MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures.MussapAutofacturaStoredProcedure;

namespace MussapAutofacturacion.Infrastructure.Contracts.Repositories
{
    public interface IShipmentRepository
    {
        IEnumerable<SpMussappRelatedFilesResult> GetRelatedFiles(long caseId, int summaryNu);
        IEnumerable<SpMussappAutofacturacionResult> GetAutofacturaPendingsSP();
        void DeletePendingInsertSended(PendingSendedDto pendingSendedDto);
        void SendDataLog(long caseId, int summaryNu, string sendData, DateTime sendDT, DateTime? receptionDT = null, string receptionData = null, string receptionErrorCode = null, string receptionErrorDescription = null);



    }
}
