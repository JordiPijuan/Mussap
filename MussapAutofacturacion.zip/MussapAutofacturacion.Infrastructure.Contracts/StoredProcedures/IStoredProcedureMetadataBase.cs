﻿namespace MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures
{
    public interface IStoredProcedureMetadataBase
    {
        string Name { get; }
    }
}