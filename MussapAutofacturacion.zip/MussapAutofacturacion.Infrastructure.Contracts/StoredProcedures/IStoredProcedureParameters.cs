﻿
namespace MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures
{
    public interface IStoredProcedureParameters
    {
    }
}

