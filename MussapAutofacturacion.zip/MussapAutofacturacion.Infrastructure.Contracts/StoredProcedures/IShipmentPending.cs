﻿using System;

namespace MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures
{
    public interface IShipmentPending
    {
        long CaseId { get; set; }
        int SummaryNu { get; set; }
        long ShipmentId { get; set; }
        long CreatedId { get; set; }
        DateTime CreatedDate { get; set; }
        int Priority { get; set; }
        long SummaryTypeId { get; set; }
        int? CaseTypeId { get; set; }
        int? SinisterTypeId { get; set; }
        int? ContractId { get; set; }
        int? ExecutiveProviderId { get; set; }
        int? BenefitPartnerId { get; set; }
        int? ServiceNu { get; set; }
        int CaseStatusId { get; set; }
        int? MonitoringNu { get; set; }
        string ExternalCase { get; set; }
        bool ExternalCaseIsValid { get ; }
        bool Reprocess { get; set; }
    }
}

