﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures.MussapAutofacturaStoredProcedure
{
    public class SpMussappAutofacturacionResult
    {
 
        public long Case_Id { get; set; }
        public int Summary_Nu { get; set; }   
        public int Shipment_Id { get; set; }
        public string Solicitante { get; set; }
        public string NombreUsuario { get; set; }
        public string PasswordUsuario { get; set; }
        public int AsistenciaRechazada { get; set; }
        public string ConceptoPago { get; set; }
        public string DocFacturaNombre { get; set; }
        public byte[] DocFacturaDatos { get; set; }
        public string DocFiniquitoConformidadClienteNombre { get; set; }
        public byte[] DocFiniquitoConformidadClienteDatos { get; set; }
        public int EsInformeDeValoracionDeDanyos { get; set; }
        public int HaIntervenidoElPerito { get; set; }
        public decimal ImporteDesplazamientos { get; set; }
        public decimal ImporteGestionExpediente { get; set; }
        public decimal ImporteHonorariosInformes { get; set; }
        public decimal ImporteManoDeObra { get; set; }
        public decimal ImporteMateriales { get; set; }
        public string NifTomador { get; set; }
        public string NumeroFactura { get; set; }
        public string NumeroSiniestro { get; set; }
        public int SiniestroFinalizado { get; set; }
        public int SiniestroNoCubierto { get; set; }
        public int SoloGestionesAsistencia { get; set; }
        //public MussapAutofacturacionDocument DocFactura { get; set; }
        //public MussapAutofacturacionDocument[] DocsFotografiasDanyos { get; set; }
        //public MussapAutofacturacionDocument docFiniquitoConformidadCliente { get; set; }

    }

    public class MussapAutofacturacionDocument
    {
        public string Datos { get; set; }
        public string Nombre { get; set; }
    }
}
