﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MussapAutofacturacion.Infrastructure.Contracts.StoredProcedures.MussapAutofacturaStoredProcedure
{
    public class SpMussappRelatedFilesResult
    {
        public string Nombre { get; set; }
        public Byte[] Datos { get; set; }
        
    }

}
